/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conectarbbdd;

/**
 *
 * @author Anima
 */
class User {
    
    String name;
    String email;
    String country;
    
    public User() {
        
    }
    
    public User(String name, String email, String country) {
        this.name = name;
        this.email = email;
        this.country = country;
    }
    
    @Override
    public String toString() {
        return "Nombre: " + this.name + "\n"
                + "Email: " + this.email + "\n"
                + "Pais: " + this.country + "\n";
    }
    
}
