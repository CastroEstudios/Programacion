
package conectarbbdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DAOUser {
   
    String host = "";
    String user = "";
    String password = "";
            
    public DAOUser() {
        this.host = "localhost:3306/dolibarr";
        this.user = "root";
        this.password = "";
    }
    
    public DAOUser(String host, String user, String password) {
        this.host = host;
        this.user = user;
        this.password = password;
    }
    
    public static void main(String[] args) {
        DAOUser prueba = new DAOUser("192.168.222.32:3306/dolibarr", "root", "");
        prueba.updateCampo("users", "country", "id", "Barbados", "102");
        prueba.mostrarTablaUSER();
    }
    
    
    public void mostrarTablaUSER() {
        
        try {
            
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" + this.host, this.user, this.password);
            Statement stm = miCon.createStatement();
            ResultSet resultSet = stm.executeQuery("SELECT * FROM users");
            
             // procesa los resultados de la consulta
            ResultSetMetaData metaDatos = resultSet.getMetaData();
            int numeroDeColumnas = metaDatos.getColumnCount();
            System.out.println( "Tabla cliente de la base de datos dolibarr: " 
                    + numeroDeColumnas + " columnas" );
 
            for ( int i = 1; i <= numeroDeColumnas; i++ ){
                System.out.printf(metaDatos.getColumnLabel(i));
            }
            System.out.println();
            
            
             while (resultSet.next()) {               
                 for (int i = 1; i <= numeroDeColumnas; i++) {
                     //System.out.print(miRs.getString(metaDatos.getColumnName( i )) + "\t" + "\t");
                     System.out.print(resultSet.getString(metaDatos.getColumnLabel(i)) + "\t" + "\t");
                 }
                 System.out.println();
            }
            
        }catch(SQLException e) {
            System.out.println("Error: "+ e.getMessage());
            System.out.println();
        }
        
    }
    
    public void insertarCampo(String tabla, String campos, String camposUsuario) {
        try {
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" + this.host, this.user, this.password);
            Statement stm = miCon.createStatement();
            String sentencia = "Insert into " + tabla + " (" + campos 
                    + ") values (" + camposUsuario + ")";
            stm.executeUpdate(sentencia);
            System.out.println("Datos insertados correctamente");
            
        }catch(SQLException e){
            System.out.println("Error: "+ e.getMessage()); 
            System.out.println();
        }
    }
    
    public void updateCampo(String tabla, String campos, String camposUsuario, 
            String campos2, String camposUsuario2) {
        try {
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" 
                    + this.host, this.user, this.password);
            Statement stm = miCon.createStatement();
            String sentencia = "Update " + tabla + " set " + campos + " = " 
                    + camposUsuario + " where " + campos2 + " = " + camposUsuario2;
            stm.executeUpdate(sentencia);
            System.out.println("Datos actualizados correctamente");
            
        }catch(SQLException e){
            System.out.println("Error: "+ e.getMessage()); 
            System.out.println();
        }
    }
    
    public void deleteCampo(String tabla, String campos, String camposUsuario, 
            String campos2) {
        try {
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" 
                    + this.host, this.user, this.password);
            Statement stm = miCon.createStatement();
            String sentencia = "delete from " + tabla + " where " + campos 
                    + " = " + campos2 + " = " + camposUsuario;
            stm.executeUpdate(sentencia);
            System.out.println("Datos eliminados correctamente");
            
        }catch(SQLException e){
            System.out.println("Error: "+ e.getMessage()); 
            System.out.println();
        }
    }
    
    
    public void selectAllUsers(String tabla, String campos, String camposUsuario, 
            String campos2) {
        try {
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" 
                    + this.host, this.user, this.password);
            Statement stm = miCon.createStatement();
            String sentencia = "exec sp_helpuser";
            stm.executeUpdate(sentencia);
            ResultSet resultSet = stm.executeQuery("SELECT * FROM users");
            ResultSetMetaData metaDatos = resultSet.getMetaData();
            int numeroColumnas = metaDatos.getColumnCount();
            
            ArrayList<String> listaUsuarios = new ArrayList<>();
            for(int i = 0; i < numeroColumnas; i++) {
                listaUsuarios.add(metaDatos.getColumnLabel(i));
            }
            
            System.out.println(listaUsuarios);
            
        }catch(SQLException e){
            System.out.println("Error: "+ e.getMessage()); 
            System.out.println();
        }
    }
    
}
