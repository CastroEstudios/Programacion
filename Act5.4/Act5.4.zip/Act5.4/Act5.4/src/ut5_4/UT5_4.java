package ut5_4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class UT5_4 {
	ArrayList<String> listaNumeros = new ArrayList<String>();
	ArrayList<String> listaNombreApellidos = new ArrayList<String>();
	File archivoUsuario;

	public UT5_4() {
	}
	
	public UT5_4(File archivoUsuario, ArrayList<String> numTelefono, ArrayList<String> nombreApellidos) {
		this.archivoUsuario = archivoUsuario;
		this.listaNumeros = numTelefono;
		this.listaNombreApellidos = nombreApellidos;
	}
	
	public void writeFile(File archivoUsuario) throws IOException {

		try {
			archivoUsuario.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			FileWriter fwrite = new FileWriter(archivoUsuario, true);
			for (int i = 0; i < listaNumeros.size(); i++) {
				fwrite.write(listaNumeros.get(i) + " - ");
				fwrite.write(listaNombreApellidos.get(i));
				fwrite.write("\r\n");
			}
			System.out.println("�Listo!");
			fwrite.close();
		} catch (SecurityException securityException) {
			System.err.println("You do not have write access to this file.");
			System.exit(1);
		} catch (FileNotFoundException filesNotFoundException) {
			System.err.println("Error creating file.");
			System.exit(1);
		}
	}
}