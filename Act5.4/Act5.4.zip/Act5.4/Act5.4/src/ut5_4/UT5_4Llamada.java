package ut5_4;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class UT5_4Llamada {

	public static void main(String[] args) throws IOException {
		File archivoUsuario = new File("./Documents/UT5_4Output.txt");
		ArrayList<String> listaNumeros = new ArrayList<String>();
		ArrayList<String> listaNombreApellidos = new ArrayList<String>();
		listaNumeros.add("822566395");
		listaNombreApellidos.add("Antonio Garcia Villaran");
		UT5_4 prueba = new UT5_4(archivoUsuario, listaNumeros, listaNombreApellidos);
		prueba.writeFile(archivoUsuario);
	}

}
