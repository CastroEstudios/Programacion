package fibonacci3_1;

public class Fibonacci3_1Llamada {

	public static void main(String[] args) {
		Fibonacci3_1 prueba = new Fibonacci3_1();
		prueba.Fibonacci1(14);
		prueba.Fibonacci2(14);
	}

}
