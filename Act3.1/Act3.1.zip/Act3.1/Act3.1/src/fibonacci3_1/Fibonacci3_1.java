package fibonacci3_1;

public class Fibonacci3_1 {

	public void Fibonacci1(int sizeSucesion) {

		int operando1 = 0;
		int operando2 = 1;
		int operandoAux;
		
		System.out.print(operando1 + ", " + operando2 + ", " + operando2);
		operando1++;
		
		for (int i = 0; i < sizeSucesion; i++) {
			operandoAux = operando2;
			System.out.print(", " + (operando2 += operando1));
			operando1 = operandoAux;
		}
		System.out.println();
	}

	public void Fibonacci2(int sizeSucesion) {
		
		int operando1 = 0;
		int operando2 = 1;
		int[] operandoAux2;
		operandoAux2 = new int[sizeSucesion];
		
		System.out.print(operando1 + ", " + operando2 + ", " + operando2);
		operando1++;
		
		for (int i = 0; i < sizeSucesion; i++) {
			operandoAux2[i] = operando2;
			System.out.print(", " + (operando2 += operando1));
			operando1 = operandoAux2[i];
		}
		System.out.println();
	}
}
