package ut5_3;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;

public class UT5_3 {

    ArrayList<String> extensionArray = new ArrayList<String>();

    public static void main(String[] args) {
        File directoryPath = new File("C://Users//Anima//Downloads//MiDir");
        File[] directoryContent = directoryPath.listFiles();
        UT5_3 prueba = new UT5_3();
        prueba.goOverDirectory(directoryContent);
        prueba.recogerContadores();
    }

    public void goOverDirectory(File[] directoryContent) {
        
        for (File content : directoryContent) {

            if (content.isDirectory()) {
                System.out.println("===========================================");
                System.out.println("+" + content.getName());

                goOverDirectory(content.listFiles()); // Calls same method again.

            } else {
                String directoryName = content.getName();
                System.out.println("    -" + directoryName);
                String fileExtension = FilenameUtils.getExtension(directoryName);
                extensionArray.add(fileExtension);
            }
        }
    }
    
    public void recogerContadores() {

    	Map<String, Long> counted = extensionArray.stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
    	 	System.out.println("===========================================");
            System.out.println(" Numero de archivos: " + counted);
    	
    }
}