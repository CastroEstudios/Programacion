package menu4_2;

import java.util.Scanner;

public class Menu4_2 {

	private String[] opcionesMenu;
	Scanner teclado = new Scanner(System.in);
	private int numUsuario;

	public Menu4_2(String[] opcionesMenu) {

	        this.opcionesMenu = opcionesMenu;
	        
	    }

	public void MenuUsuario() {

		do {
			System.out.println("-1: Salir");
			for (int i = 1; i <= opcionesMenu.length; i++) {
				System.out.println(i + ": " + opcionesMenu[i-1]);
			}
			System.out.print("Introduzca el n�mero de la opci�n que desea ejecutar: ");
			numUsuario = teclado.nextInt();
			if (numUsuario <= opcionesMenu.length && numUsuario > 0) {
				System.out.println(opcionesMenu[numUsuario-1]);
			}else if(numUsuario==-1) {
			}else{
				System.out.println("Introduzca una opci�n v�lida.");
			}
			System.out.println();
		} while (numUsuario != -1);
		System.out.println("Hasta luego");
	}
}
