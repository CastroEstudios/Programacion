package menu4_2;

public class Menu4_2Llamada {

    public static void main(String[] args){
    	String [] opcionesMenu = {"Hola", "Buenas", "Tardes"};
        Menu4_2 prueba = new Menu4_2(opcionesMenu);
        prueba.MenuUsuario();
    }

}
