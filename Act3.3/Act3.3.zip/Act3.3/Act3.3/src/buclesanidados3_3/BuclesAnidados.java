
package buclesanidados3_3;

/**
 *
 * @author Daniel
 */
public class BuclesAnidados {

	public void BuclesAnidados1(int numUsuario) {
		int contadorBucle = 0;
		int contadorAsterisco = 0;

		while (contadorBucle < numUsuario) {
			while (contadorAsterisco < numUsuario) {
				System.out.print("*");
				contadorAsterisco++;
			}
			System.out.println();
			contadorBucle++;
			contadorAsterisco = 0;
		}
		System.out.println();
		System.out.println("===================================");
	}

	public void BuclesAnidados2(int numUsuario) {
		for (int i = 0; i <= numUsuario; i++) {
			for (int j = 0; j < i; j++) {
				System.out.print(j + 1);
			}
			System.out.println();
		}
		System.out.println();
		System.out.println("===================================");
		System.out.println();
	}

	public void BuclesAnidados3(int numUsuario) {
		while(numUsuario > 0) {
			for (int j = 0; j < numUsuario; j++) {
				System.out.print(numUsuario - j);
			}
			numUsuario--;
			System.out.println();
		}
		System.out.println();
		System.out.println("===================================");
		System.out.println();
	}
	
	public void BuclesAnidados4(int numUsuario) {
		int contadorBucle = numUsuario;
		String asterisco = "*";
		System.out.print(asterisco.repeat(numUsuario+1));
		System.out.println();
		System.out.println();
		while(contadorBucle > 1) {
			System.out.format("*" + "%1$" + numUsuario + "s", "" + "*");
			System.out.println();
			System.out.println();
			contadorBucle--;
		}
		System.out.print(asterisco.repeat(numUsuario+1));
		System.out.println();
		System.out.println();
		System.out.println("===================================");
		System.out.println();
	}
	
	public void BuclesAnidados5(int numUsuario) {
		
	}
}
