package buclesanidados3_3;

public class BuclesAnidadosLlamada {

	public static void main(String[] args) {
		BuclesAnidados prueba = new BuclesAnidados();
		int numUsuario = 5;
		prueba.BuclesAnidados1(numUsuario);
		prueba.BuclesAnidados2(numUsuario);
		prueba.BuclesAnidados3(numUsuario);
		prueba.BuclesAnidados4(numUsuario);
	}
}
