package contarvocales3_2;

public class ContarVocalesLlamada {

	public static void main(String[] args) {
		String fraseUsuario = "Una vaina loca";
		ContarVocales prueba = new ContarVocales();
		
		System.out.println("Hay " + prueba.ContarVocalesOptimo(fraseUsuario)
		+ " vocales");
 		System.out.println("Hay " + prueba.ContarVocalesDos(fraseUsuario)
		+ " vocales");
	}
}
