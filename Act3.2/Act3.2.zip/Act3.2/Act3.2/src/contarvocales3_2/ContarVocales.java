package contarvocales3_2;

public class ContarVocales {

	public int ContarVocalesOptimo(String fraseUsuario) {
		int contadorVocales = 0;

		for (int i = 0; i < fraseUsuario.length(); i++) {
			char letraActual = fraseUsuario.charAt(i);

			if ("AEIOUaeiou".indexOf(letraActual) != -1) {
				contadorVocales++;
			}
		}
		return contadorVocales;
	}
	
	public int ContarVocalesDos(String fraseUsuario) {
		final char[] VOCALES = {'a','e','i','o','u'};
		int contadorVocales = 0;
		fraseUsuario = fraseUsuario.toLowerCase();

		for (int i = 0; i < fraseUsuario.length(); i++) {
			for (int j = 0; j < VOCALES.length; j++) {
				if(VOCALES[j] == fraseUsuario.charAt(i)) {
					contadorVocales++;
				}
			}
		}
		return contadorVocales;
	}
}
