package act3_4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Arrays;
import java.util.Scanner;
/**
 *
 * @author Daniel 
 */
public class UT3_4 {
    
    public static void main(String[] args){
        int notaAlumno = 0;
        int contadorNotas = 0;
        int sumaMedia = 0;
        int[] notasArray = new int[30];
        String[] asteriscosCero = new String[30];
        Arrays.fill(asteriscosCero, "");
        
        /* Pedir las notas al usuario */
        
        while (notaAlumno != -1){
            Scanner teclado = new Scanner(System.in);
            System.out.print("Escriba la nota: ");
            notaAlumno = teclado.nextInt();
            notasArray[contadorNotas] = notaAlumno;
            contadorNotas++;
        }
        
        /* Contar el número de notas de cada rango*/
        
        for (int contadorArray = 0 ; notasArray[contadorArray] != -1 ; contadorArray++){
            
            switch (notasArray[contadorArray]) {
                case 0:
                    if (asteriscosCero[0] == null){
                        asteriscosCero[0] = "*";
                    }else if (asteriscosCero[0] != null){
                        asteriscosCero[0] = asteriscosCero[0] + "*";
                    }   break;
                case 1:
                    if (asteriscosCero[1] == null){
                        asteriscosCero[1] = "*";
                    }else if (asteriscosCero[1] != null){
                        asteriscosCero[1] = asteriscosCero[1] + "*";
                    }   break;
                case 2:
                    if (asteriscosCero[2] == null){
                        asteriscosCero[2] = "*";
                    }else if (asteriscosCero[2] != null){
                        asteriscosCero[2] = asteriscosCero[2] + "*";
                    }   break;
                case 3:
                    if (asteriscosCero[3] == null){
                        asteriscosCero[3] = "*";
                    }else if (asteriscosCero[3] != null){
                        asteriscosCero[3] = asteriscosCero[3] + "*";
                    }   break;
                case 4:
                    if (asteriscosCero[4] == null){
                        asteriscosCero[4] = "*";
                    }else if (asteriscosCero[4] != null){
                        asteriscosCero[4] = asteriscosCero[4] + "*";
                    }   break;
                case 5:
                    if (asteriscosCero[5] == null){
                        asteriscosCero[5] = "*";
                    }else if (asteriscosCero[5] != null){
                        asteriscosCero[5] = asteriscosCero[5] + "*";
                    }   break;
                case 6:
                    if (asteriscosCero[6] == null){
                        asteriscosCero[6] = "*";
                    }else if (asteriscosCero[6] != null){
                        asteriscosCero[6] = asteriscosCero[6] + "*";
                    }   break;
                case 7:
                    if (asteriscosCero[7] == null){
                        asteriscosCero[7] = "*";
                    }else if (asteriscosCero[7] != null){
                        asteriscosCero[7] = asteriscosCero[7] + "*";
                    }   break;
                case 8:
                    if (asteriscosCero[8] == null){
                        asteriscosCero[8] = "*";
                    }else if (asteriscosCero[8] != null){
                        asteriscosCero[8] = asteriscosCero[8] + "*";
                    }   break;
                case 9:
                    if (asteriscosCero[9] == null){
                        asteriscosCero[9] = "*";
                    }else if (asteriscosCero[9] != null){
                        asteriscosCero[9] = asteriscosCero[9] + "*";
                    }   break;
                case 10:
                    if (asteriscosCero[10] == null){
                        asteriscosCero[10] = "*";
                    }else if (asteriscosCero[10] != null){
                        asteriscosCero[10] = asteriscosCero[10] + "*";
                    }   break;
                default:
                    break;
            }
        }
        
        /* Enseñamos los datos */
        
        for (int contadorPrint = 0 ; contadorPrint < 10 ; contadorPrint++){
        System.out.println("Alumnos con nota de " + contadorPrint + ": " + asteriscosCero[contadorPrint]);
        }
        for (int contadorMedia = 0 ; contadorMedia <= contadorNotas ; contadorMedia++){
            sumaMedia = sumaMedia + notasArray[contadorMedia];
        }
        int mediaNotas = sumaMedia/(contadorNotas-1);
        System.out.println("La media de las notas es de: " + mediaNotas);
    }
}