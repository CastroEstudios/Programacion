package ut5_5;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UT5_5 {

	public static void main(String[] args) {
		String numTelefono = "622175638";
		UT5_5 pruebaTelefono = new UT5_5();
		if (pruebaTelefono.validarNumeroTelefono(numTelefono) == true) {
			System.out.println("N�mero correcto");
		}else {
			System.out.println("N�mero incorrecto");
		}
		
		String email = "unavainaloca@gmail.com";
		UT5_5 pruebaEmail = new UT5_5();
		if (pruebaEmail.validarEmail(email) == true) {
			System.out.println("Email correcto");
		}else {
			System.out.println("Email incorrecto");
		}
		
		String matricula = "9564BCD";
		UT5_5 pruebaMatricula = new UT5_5();
		if (pruebaMatricula.validarMatricula(matricula) == true) {
			System.out.println("Matricula correcta");
		}else {
			System.out.println("Matricula incorrecta");
		}
		
		String telefonoFijo = "922175866";
		UT5_5 pruebaFijo = new UT5_5();
		if (pruebaFijo.validarFijo(telefonoFijo) == true) {
			System.out.println("Fijo correcto");
		}else {
			System.out.println("Fijo incorrecto");
		}
		
		String telefonoFijoGC = "828175866";
		UT5_5 pruebaFijoGC = new UT5_5();
		if (pruebaFijoGC.validarFijo(telefonoFijoGC) == true) {
			System.out.println("FijoGC correcto");
		}else {
			System.out.println("FijoGC incorrecto");
		}
		
	}

	public boolean validarNumeroTelefono(String numTelefono) {
		Pattern numeroCorrecto = Pattern.compile("(\\+34|0034|34)?[ -]*(6|7)[ -]*([0-9][ -]*){8}");
		Matcher corrector = numeroCorrecto.matcher(numTelefono);
		return corrector.matches();
	}
	
	public boolean validarEmail(String email) {
		Pattern emailCorrecto = Pattern.compile("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9]))\\.){3}(?:(2(5[0-5]|[0-4][0-9])|1[0-9][0-9]|[1-9]?[0-9])|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])");
		Matcher corrector = emailCorrecto.matcher(email);
		return corrector.matches();
	}
	
	public boolean validarMatricula(String matricula) {
		Pattern matriculaCorrecto = Pattern.compile("^[0-9]{1,4}(?!.*(LL|CH))[BCDFGHJKLMNPRSTVWXYZ]{3}");
		Matcher corrector = matriculaCorrecto.matcher(matricula);
		return corrector.matches();
	}
	
	public boolean validarFijo(String telefonoFijo) {
		Pattern fijoCorrecto = Pattern.compile("(\\+34|0034|34)?[ -]*(8|9)[ -]*([0-9][ -]*){8}");
		Matcher corrector = fijoCorrecto.matcher(telefonoFijo);
		return corrector.matches();
	}
	
	public boolean validarFijoGC(String telefonoFijoGC) {
		Pattern fijoGCCorrecto = Pattern.compile("(\\+34|0034|34)?[ -]*(828|928)[ -]*([0-9][ -]*){8}");
		Matcher corrector = fijoGCCorrecto.matcher(telefonoFijoGC);
		return corrector.matches();
	}
}
