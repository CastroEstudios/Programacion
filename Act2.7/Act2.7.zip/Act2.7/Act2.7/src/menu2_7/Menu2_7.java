package menu2_7;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

//Clase Menu
public class Menu2_7 {

	String[] menuOpciones;
	int operando1;
	int operando2;
	File MenuLog = new File("MenuLog.txt");

	//Constructor parametrizado
	public Menu2_7(String[] menuOpciones, int operando1, int operando2) {
		this.menuOpciones = menuOpciones;
		this.operando1 = operando1;
		this.operando2 = operando2;
	}

	/*
	 * M�todo principal del men�, en �l se crea un men� y las distintas opciones del
	 * men�, llaman a los correspondientes m�todos de Menu2_7Calculadora.
	 */
	public void menuOpciones() throws InterruptedException {

		Scanner teclado = new Scanner(System.in);
		int opcionUsuario = 0;
		System.out.println("Bienvenido al men�, elija una opci�n:");

		//Ense�amos al usuario las distintas opciones y le comunicamos
		//que tiene que elegir una opci�n.
		do {
			System.out.println();
			System.out.println("-1: Salir del men�");
			for (int i = 0; i < menuOpciones.length; i++) {
				System.out.println(i + ". " + menuOpciones[i]);
			}

			System.out.print("Introduzca una opcion: ");
			opcionUsuario = teclado.nextInt();

			//Llamamos al m�todo writeLogFile
			try {
				writeLogFile(opcionUsuario, MenuLog);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			//Definimos una nueva instancia de calculadora para llamar a sus m�todos en las
			//distintas opciones del switch
			Menu2_7Calculadora LlamadaCalculadora = new Menu2_7Calculadora(operando1, operando2);

			switch (opcionUsuario) {
			case -1:
				break;
			case 0:
				LlamadaCalculadora.suma(operando1, operando2);
				System.out.println("El resultado es: " + LlamadaCalculadora.getResultado());
				break;
			case 1:
				LlamadaCalculadora.resta(operando1, operando2);
				System.out.println("El resultado es: " + LlamadaCalculadora.getResultado());
				break;
			case 2:
				LlamadaCalculadora.multiplicacion(operando1, operando2);
				System.out.println("El resultado es: " + LlamadaCalculadora.getResultado());
				break;
			case 3:
				LlamadaCalculadora.division(operando1, operando2);
				System.out.println("El resultado es: " + LlamadaCalculadora.getResultado());
				break;
			case 4:
				System.out.println("Profe, me lo estoy currando.");
				break;
			default:
				System.out.println("Introduzca una opcion valida.");
			}

			//Breve pausa antes de mostrar el men� de nuevo
			TimeUnit.SECONDS.sleep(1);

		} while (opcionUsuario != -1);
		System.out.println();
		System.out.println("Menu cerrado");
		teclado.close();
	}		

	//M�todo para realizar un log de las opciones seleccionadas por el usuario.
	public void writeLogFile(int opcionUsuario, File MenuLog) throws IOException {

		//Creamos el archivo para el log
		try {
			MenuLog.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			FileWriter fwrite = new FileWriter(MenuLog, true);
			SimpleDateFormat dateformatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			fwrite.write(dateformatter.format(date) + " | " + "Input: " + opcionUsuario + "\n");
			fwrite.close();
		} catch (SecurityException securityException) {
			System.err.println("You do not have write access to this file.");
			System.exit(1);
		} // end catch
		catch (FileNotFoundException filesNotFoundException) {
			System.err.println("Error creating file.");
			System.exit(1);
		} // end catch
	}

}
