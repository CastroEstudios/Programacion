package menu2_7;

public class Menu2_7Llamada {
	
	public static void main(String[] args) throws InterruptedException {
		
		String[] menuOpciones = {"Suma", "Resta",
				"Multiplicaci�n", "Divisi�n", "Profe"};
		int operando1 = 5;
		int operando2 = 8;
		
		Menu2_7 prueba = new Menu2_7(menuOpciones, operando1, operando2);
		prueba.menuOpciones();
		
	}

}
