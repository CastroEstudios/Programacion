package ut5_6;



import java.util.ArrayList;
import java.util.Collections;



public class UT5_6 {

	
	
	ArrayList<Integer> listaNumeros = new ArrayList<>();
	ArrayList<String> listaString = new ArrayList<>();
	ArrayList<Persona> listaPersona = new ArrayList<>();
	
	
	
	public static void main(String[] args) {
		
		System.out.println();
		
		int[] numeros = {8, 4, 2, 0, 9, 1};
		
		UT5_6 prueba = new UT5_6();
		prueba.ordenarNumeros(numeros);
		
		String[] palabros = {"Etéreo", "Sobresaliente", "Sopa", "Glacial"};
		
		prueba.ordenarStrings(palabros);
		
		prueba.ordenarPersonas();
		
	}
	
	
	
	public void ordenarNumeros(int[] numeros) {
		
		for(int i = 0; i < numeros.length; i++) {
			listaNumeros.add(numeros[i]);
		}
		
		System.out.println("Datos desordenados:");
		mostrarArray(listaNumeros);
		
		Collections.sort(listaNumeros);

		System.out.println("Datos ordenados:");
		mostrarArray(listaNumeros);
		
		Collections.reverse(listaNumeros);
		System.out.println("Datos en reversa:");
		mostrarArray(listaNumeros);
		
		ArrayList<Integer> valoresInsercion = new ArrayList<Integer>();
		valoresInsercion.add(7);
		valoresInsercion.add(205);
		valoresInsercion.add(45);
		valoresInsercion.add(400);
		valoresInsercion.add(-2);
		valoresInsercion.add(4);
		
		insercionOrdenadaNumeros(listaNumeros, valoresInsercion);
		mostrarArray(listaNumeros);
	}
	
	
	
	public void ordenarStrings(String[] palabros) {
		
		for(int i = 0; i < palabros.length; i++) {
			listaString.add(palabros[i]);
		}
		
		System.out.println("Datos desordenados:");
		mostrarArray(listaString);
		
		Collections.sort(listaString);
		
		System.out.println("Datos ordenados:");
		mostrarArray(listaString);
		
		Collections.reverse(listaString);
		System.out.println("Datos en reversa:");
		mostrarArray(listaString);
		
		ArrayList<String> valoresInsercion = new ArrayList<String>();
		valoresInsercion.add("Heraldo");
		valoresInsercion.add("Helado");
		valoresInsercion.add("Aamulehti");
		valoresInsercion.add("Xenoverse");
		valoresInsercion.add("Marco Antonio");
		
		insercionOrdenadaString(listaString, valoresInsercion);
		mostrarArray(listaString);
	}

	
	
	public void ordenarPersonas() {	
		
		listaPersona.add(new Persona("Antonio", "García", "Villarán", 45, "masculino"));
		listaPersona.add(new Persona("Daniel", "Castro", "Cruz", 21, "masculino"));
		listaPersona.add(new Persona("Gustavo", "Alfredo", "Santaolalla", 70, "masculino"));
		
		System.out.println("Datos desordenados:");
		mostrarArray(listaPersona);
		
		Collections.sort(listaPersona);
		
		System.out.println("Datos ordenados:");
		mostrarArray(listaPersona);
		
		Collections.reverse(listaPersona);
		System.out.println("Datos en reversa:");
		mostrarArray(listaPersona);
		
		ArrayList<Persona> valoresInsercion = new ArrayList<Persona>();
		valoresInsercion.add(new Persona("Kentaro", "Miura", "", 999, "masculino"));
		valoresInsercion.add(new Persona("Juan", "Ramón", "Rallo", 38, "masculino"));
		valoresInsercion.add(new Persona("Keiichi", "Okabe", "", 52, "masculino"));
		valoresInsercion.add(new Persona("Emi", "Evans", "", 41, "femenino"));
		
		insercionOrdenadaPersona(listaPersona, valoresInsercion);
		mostrarArray(listaPersona);
	}
	
	
	
	public void mostrarArray(ArrayList<?> listaOrdenar) {
		
		System.out.println();
		
		for(int j = 0; j < listaOrdenar.size(); j++) {
			System.out.println(listaOrdenar.get(j));
		}	
		
		System.out.println();
		System.out.println("----------------------o----------------------");
		System.out.println();
		
	}
	
	
	
	public void insercionOrdenadaNumeros(ArrayList<Integer> listaOrdenar, ArrayList<Integer> valoresInsercion) {
		
		for(int i = 0; i < valoresInsercion.size(); i++) {
			for(int j = 0; j < listaOrdenar.size(); j++) {
				if(valoresInsercion.get(i) > listaOrdenar.get(j)) {
					listaOrdenar.add(j, valoresInsercion.get(i));
					j = listaOrdenar.size();
				}else if(valoresInsercion.get(i) == listaOrdenar.get(j)) {
					j = listaOrdenar.size();
				}else if(valoresInsercion.get(i) < listaOrdenar.get(j)) {
					if(j == listaOrdenar.size()-1) {
						listaOrdenar.add(valoresInsercion.get(i));
					}
				}
			}
		}	
	}
	
	
	
	public void insercionOrdenadaString(ArrayList<String> listaOrdenar, ArrayList<String> valoresInsercion) {
			
			for(int i = 0; i < valoresInsercion.size(); i++) {
				for(int j = 0; j < listaOrdenar.size(); j++) {
					if((valoresInsercion.get(i)).compareTo(listaOrdenar.get(j)) > 0) {
						listaOrdenar.add(j, valoresInsercion.get(i));
						j = listaOrdenar.size();
					}else if((valoresInsercion.get(i)).compareTo(listaOrdenar.get(j)) == 0) {
						j = listaOrdenar.size();
					}else if((valoresInsercion.get(i)).compareTo(listaOrdenar.get(j)) < 0) {
						if(j == listaOrdenar.size()-1) {
							listaOrdenar.add(valoresInsercion.get(i));
						}
					}
				}
			}	
		}
	
	
	
	public void insercionOrdenadaPersona(ArrayList<Persona> listaOrdenar, ArrayList<Persona> valoresInsercion) {
		
		for(int i = 0; i < valoresInsercion.size(); i++) {
			for(int j = 0; j < listaOrdenar.size(); j++) {
				if((valoresInsercion.get(i)).compareTo(listaOrdenar.get(j)) > 0) {
					listaOrdenar.add(j, valoresInsercion.get(i));
					j = listaOrdenar.size();
				}else if((valoresInsercion.get(i)).compareTo(listaOrdenar.get(j)) == 0) {
					j = listaOrdenar.size();
				}else if((valoresInsercion.get(i)).compareTo(listaOrdenar.get(j)) < 0) {
					if(j == listaOrdenar.size()-1) {
						listaOrdenar.add(valoresInsercion.get(i));
					}
				}
			}
		}	
	}
	
}
