/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package inventariorfid.interfaces;

import inventariorfid.classes.Marcajes;
import java.sql.SQLException;

public interface SubmenuMarcajesDAO {
    
    public int submenu(Marcajes marcaje) throws SQLException;
    public boolean insertar(Marcajes marcaje) throws SQLException;
    public boolean listar(Marcajes marcaje) throws SQLException;
    public boolean eliminar(Marcajes marcaje) throws SQLException;
    public boolean modificar(Marcajes marcaje) throws SQLException;
    
}
