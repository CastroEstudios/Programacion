/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package inventariorfid.interfaces;

import inventariorfid.classes.Aula;
import java.sql.SQLException;

public interface SubmenuAulaDAO {
    
    public int submenu(Aula aula) throws SQLException;
    public boolean insertar(Aula aula) throws SQLException;
    public boolean listar(Aula aula) throws SQLException;
    public boolean eliminar(Aula aula) throws SQLException;
    public boolean modificar(Aula aula) throws SQLException;
    
}
