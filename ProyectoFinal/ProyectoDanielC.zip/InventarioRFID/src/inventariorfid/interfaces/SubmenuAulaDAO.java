/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package inventariorfid.interfaces;

import inventariorfid.classes.Aula;

public interface SubmenuAulaDAO {
    
    public int submenu();
    public boolean crear();
    public boolean insertar(Aula aula);
    public boolean listar(Aula aula);
    public boolean eliminar(Aula aula);
    public boolean modificar(Aula aula);
    
}
