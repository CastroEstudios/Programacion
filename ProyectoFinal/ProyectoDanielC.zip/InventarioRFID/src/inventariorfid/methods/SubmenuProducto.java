/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import inventariorfid.classes.Producto;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import inventariorfid.interfaces.SubmenuProductoDAO;
import java.util.Scanner;

public class SubmenuProducto implements SubmenuProductoDAO {
    
    String sentencia = "";
    boolean correcto = false;
    Producto nuevoProducto = new Producto();
    
    @Override
    public int submenu(Producto producto) throws SQLException {
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 2 - Productos");
                System.out.println("1 - Insertar Producto");
                System.out.println("2 - Listar Producto");
                System.out.println("3 - Eliminar Producto");
                System.out.println("4 - Modificar Producto");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1 -> {
                        insertar(producto);
                        System.out.println();
                    }
                    case 2 -> {
                        listar(producto);
                        System.out.println();
                    }
                    case 3 -> {
                        eliminar(producto);
                        System.out.println();
                    }
                    case 4 -> {
                        modificar(producto);
                        System.out.println();
                    }
                    case 0 -> {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default -> {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return opcionUser;
    }
    
    @Override
    public boolean insertar(Producto producto) throws SQLException {
        
        try {
            Connection miCon = producto.productoConnection();
            
            sentencia = (
            "INSERT INTO productos (descripcion, ean13, keyRFID) VALUES (?,?,?);"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setString(1, producto.getDescripcion());
            pstm.setString(2, producto.getEAN13());
            pstm.setString(3, producto.getkeyRFID());
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
        }
        
        catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }

        return correcto;
    }

    @Override
    public boolean listar(Producto producto) throws SQLException {
       
        try{
            Connection miCon = producto.productoConnection();

            sentencia = ("SELECT * from productos");

            PreparedStatement pstm = miCon.prepareStatement(sentencia);

            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }

    @Override
    public boolean eliminar(Producto producto) throws SQLException {
        
        try {
            Connection miCon = producto.productoConnection();
            
            sentencia = ("DELETE FROM productos WHERE idProducto = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, producto.getID());
            pstm.executeUpdate();
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e){
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
        
    }

    @Override
    public boolean modificar(Producto producto) throws SQLException {
        
        try {
            Connection miCon = producto.productoConnection();
            
            sentencia = ("UPDATE productos SET descripcion = ? WHERE idProducto = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setString(1, producto.getDescripcion());
            pstm.setInt(2, producto.getID());
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
    
}
