/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Anima
 */
public class SubmenuDatos {
    
    boolean correcto = false;
    File file = new File(".\\Aula_fecha.dat");
    
    public int submenu() {
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 5 - Datos");
                System.out.println("1 - Cargar datos de Prueba a fichero.");
                System.out.println("2 - Guardar datos de Prueba a fichero.");
                System.out.println("3 - Cargar datos de Base de Datos.");
                System.out.println("4 - Guardar datos de Base de Datos.");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1 -> {
                        cargarDatos(file);
                        System.out.println();
                    }
                    case 2 -> {
                        System.out.println();
                    }
                    case 3 -> {
                        System.out.println();
                    }
                    case 4 -> {
                        System.out.println();
                    }
                    case 0 -> {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default -> {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();

        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        return opcionUser;
        
    }
    
    public boolean cargarDatos(File file) {
        
        Scanner s = null;
        ArrayList<String> fileContent = new ArrayList();
        
        try {
            s = new Scanner(file);
            while(s.hasNextLine()) {
            fileContent.add(s.nextLine());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        return correcto;
        
    }
    
}
