
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;
import inventariorfid.interfaces.SubmenuAulaDAO;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SubmenuAula implements SubmenuAulaDAO {
    
    String sentencia = "";
    boolean correcto = false;
    ArrayList<Aula> listaAulas = new ArrayList();
    
    @Override
    public int submenu(){
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 1 - Aulas");
                System.out.println("1 - Crear Aula");
                System.out.println("2 - Insertar Aula");
                System.out.println("3 - Listar Aulas");
                System.out.println("4 - Eliminar Aula");
                System.out.println("5 - Modificar Aula");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1 -> {
                        crear();
                        System.out.println();
                    }
                    case 2 -> {
                        insertar(aula);
                        System.out.println();
                    }
                    case 3 -> {
                        listar(aula);
                        System.out.println();
                    }
                    case 4 -> {
                        eliminar(aula);
                        System.out.println();
                    }
                    case 5 -> {
                        modificar(aula);
                        System.out.println();
                    }
                    case 0 -> {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default -> {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        } catch (ParseException ex) {
            Logger.getLogger(SubmenuAula.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return opcionUser;
    }
    
    @Override
    public boolean crear() {
        Scanner s = new Scanner(System.in);
        System.out.print("Introduzca el ID del aula: ");
        int idAula = s.nextInt();
        System.out.print("Introduzca la numeración del aula: ");
        String numeracionAula = s.nextLine();
        System.out.print("Introduzca la descripción del aula: ");
        String descripcionAula = s.nextLine();
        System.out.print("Introduzca la IP del aula: ");
        String ipAula = s.nextLine();
        Aula aula = new Aula(idAula, numeracionAula, descripcionAula, ipAula);
        listaAulas.add(aula);
        return correcto;
    }
    
    @Override
    public boolean insertar(Aula aula) {
        
        try {
            Connection miCon = aula.aulaConnection();
            
            sentencia = (
            "INSERT INTO aulas (numeracion, descripcion, ip) VALUES (?,?,?);"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setString(1, aula.getNumeracion());
            pstm.setString(2, aula.getDescription());
            pstm.setString(3, aula.getIp());
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
        }
        
        catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }

        return correcto;
    }
    
    @Override
    public boolean listar(Aula aula) {
        
        try {
            Connection miCon = aula.aulaConnection();

            sentencia = ("SELECT * from aulas");

            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for (int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            System.out.println();

            while (rs.next()) {               
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
        
    }
    
    @Override
    public boolean eliminar(Aula aula) {
        
        try {
            Connection miCon = aula.aulaConnection();
            
            sentencia = ("DELETE FROM aulas WHERE idAula = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, aula.getID());
            pstm.executeUpdate();
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
        
    }
    
    @Override
    public boolean modificar(Aula aula) {
        
        try {
            Connection miCon = aula.aulaConnection();
            
            sentencia = ("UPDATE aulas SET descripcion = ? WHERE idAula = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setString(1, aula.getDescription());
            pstm.setInt(2, aula.getID());
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
    }
    
}
