/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import inventariorfid.classes.Marcajes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;
import inventariorfid.interfaces.SubmenuMarcajesDAO;

public class SubmenuMarcajes implements SubmenuMarcajesDAO {
    
    String sentencia = "";
    boolean correcto = false;
    
    @Override
    public int submenu(Marcajes marcaje) throws SQLException{
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 3 - Marcajes");
                System.out.println("1 - Insertar Marcaje");
                System.out.println("2 - Listar Marcajes");
                System.out.println("3 - Eliminar Marcaje");
                System.out.println("4 - Modificar Marcaje");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1 -> {
                        insertar(marcaje);
                        System.out.println();
                    }
                    case 2 -> {
                        listar(marcaje);
                        System.out.println();
                    }
                    case 3 -> {
                        eliminar(marcaje);
                        System.out.println();
                    }
                    case 4 -> {
                        modificar(marcaje);
                        System.out.println();
                    }
                    case 0 -> {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default -> {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return opcionUser;
    }
    
    @Override
    public boolean insertar(Marcajes marcaje) throws SQLException {
        
        try {
            Connection miCon = marcaje.marcajesConnection();
            
            sentencia = (
            "INSERT INTO marcajes (idProducto, idAula, ipo, Timestamp) VALUES (?,?,?,?);"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, marcaje.getIdProducto());
            pstm.setInt(2, marcaje.getIdAula());
            pstm.setObject(3, marcaje.getIpo());
            pstm.setTimestamp(4, marcaje.getTimestamp());
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
        }
        
        catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }

        return correcto;
    }
    
    @Override
    public boolean listar(Marcajes marcaje) throws SQLException {
        
        try {
            Connection miCon = marcaje.marcajesConnection();

            sentencia = ("SELECT * from marcajes");

            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for (int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            System.out.println();

            while (rs.next()) {               
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();
            
        }catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
        
    }
    
    @Override
    public boolean eliminar(Marcajes marcaje) throws SQLException {
        
        try {
            Connection miCon = marcaje.marcajesConnection();
            
            sentencia = ("DELETE FROM marcajes WHERE idMarcajes = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, marcaje.getIdMarcaje());
            pstm.executeUpdate();
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
        
    }
    
    @Override
    public boolean modificar(Marcajes marcaje) throws SQLException {
        
        try {
            Connection miCon = marcaje.marcajesConnection();
            
            sentencia = ("UPDATE marcajes SET ipo = ? WHERE idMarcajes = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setObject(1, marcaje.getIpo());
            pstm.setInt(2, marcaje.getIdMarcaje());
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
    }
    
}
