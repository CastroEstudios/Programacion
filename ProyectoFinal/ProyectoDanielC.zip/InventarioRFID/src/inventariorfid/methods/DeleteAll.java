/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Anima
 */
public class DeleteAll {
    
    String sentencia = "";
    boolean correcto = true;
    
    public boolean eliminar(Aula aula) throws SQLException {
        
        try {
            Connection miCon = aula.aulaConnection();
            
            sentencia = ("DELETE FROM aulas WHERE idAula = ?");
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, aula.getID());
            pstm.executeUpdate();
            int columnasAfectadas = pstm.executeUpdate();
            
            if(columnasAfectadas > 0) {
            correcto = true;
            }
            
        }catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
        
    }
    
}
