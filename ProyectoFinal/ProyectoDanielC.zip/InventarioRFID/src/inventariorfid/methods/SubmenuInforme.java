
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import inventariorfid.classes.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class SubmenuInforme {
    
    String sentencia = "";
    boolean correcto = false;
    Producto nuevoProducto = new Producto();
    
    public int submenu(Producto producto, Aula aula) 
            throws SQLException, ParseException {
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 4 - Informes");
                System.out.println("1 - Mostrar los fichajes de un producto"
                        + " ordenados por fecha");
                System.out.println("2 - Mostrar los fichajes de un aula entre"
                        + " dos fechas");
                System.out.println("3 - Mostrar los fichajes de un producto" 
                        + "y un aula");
                System.out.println("4 - Informe a crear por el alumno");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1 -> {
                        mostrarFichajesProducto(producto);
                        System.out.println();
                    }
                    case 2 -> {
                        mostrarFichajesAula(aula);
                        System.out.println();
                    }
                    case 3 -> {
                        mostrarFichajesAulaProducto(aula, producto);
                        System.out.println();
                    }
                    case 4 -> {
                        System.out.println();
                    }
                    case 0 -> {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default -> {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return opcionUser;
    }
    
    public boolean mostrarFichajesProducto(Producto producto) {
        
        try {
            Connection miCon = nuevoProducto.productoConnection();
            
            sentencia = (
                    "SELECT * "
                    + "FROM marcajes "
                    + "WHERE idProducto = ? "
                    + "ORDER BY Timestamp desc"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, producto.getID());
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) 
                            + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
    
    public boolean mostrarFichajesAula(Aula aula) throws ParseException {
        
        try {
            
            String fechaInicialString = "20-May-2022";
            String fechaFinalString = "30-May-2026";
        
            SimpleDateFormat f = new SimpleDateFormat("dd-MMM-yyyy");

            Date dI = f.parse(fechaInicialString);
            long millisecondsI = dI.getTime();
            Timestamp fechaInicial = new Timestamp(millisecondsI);
            
            Date dF = f.parse(fechaFinalString);
            long millisecondsF = dF.getTime();
            Timestamp fechaFinal = new Timestamp(millisecondsF);
            
            Connection miCon = nuevoProducto.productoConnection();
            
            sentencia = (
                    "SELECT * "
                    + "FROM marcajes "
                    + "WHERE idAula = ? and Timestamp between ? and ? "
                    + "ORDER BY Timestamp desc"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, aula.getID());
            pstm.setTimestamp(2, fechaInicial);
            pstm.setTimestamp(3, fechaFinal);
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) 
                            + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
    
    public boolean mostrarFichajesAulaProducto(Aula aula, Producto producto) 
            throws ParseException {
        
        try {
            
            Connection miCon = nuevoProducto.productoConnection();
            
            sentencia = (
                    "SELECT * "
                    + "FROM marcajes "
                    + "WHERE idAula = ? and idProducto = ? "
                    + "ORDER BY Timestamp desc"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            pstm.setInt(1, aula.getID());
            pstm.setInt(2, producto.getID());
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
}
