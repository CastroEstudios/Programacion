/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import inventariorfid.classes.Marcajes;
import inventariorfid.classes.Producto;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

/**
 *
 * @author Anima
 */
public class MenuPrincipal {
    
    public static void main(String[] args) throws SQLException, ParseException {

        MenuPrincipal mp = new MenuPrincipal();
        mp.MenuPrincipal();
        
    }
    
    public ArrayList datosLista() {
        
        Calendar calendar = Calendar.getInstance();
        Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
        Aula aula = new Aula(16, "1.1.2", "Aula 2, Piso 1, Pabellon 1", "192.168.112.1");
        Producto producto = new Producto(12, "Teclado gaming XSD", "1298744812236", "JB03DK6");
        Marcajes marcaje = new Marcajes(14, producto, aula, "ENTRADA", timestamp);
        
        ArrayList listaDatos = new ArrayList();
        listaDatos.add(aula.toString());
        listaDatos.add(producto.toString());
        listaDatos.add(marcaje.toString());
        
        return listaDatos;
    }
    
    public int MenuPrincipal() throws SQLException, ParseException {
            
        Scanner s = new Scanner(System.in);
        int opcionUser = 0;
        
        do {
            System.out.println("Menu Principal");
            System.out.println("1 - Gestion Aulas.");
            System.out.println("2 - Gestion Productos.");
            System.out.println("3 - Gestion Marcajes.");
            System.out.println("4 - Informes.");
            System.out.println("5 - Datos.");
            System.out.println("0 - Salir");
            System.out.print("Introduzca una opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    SubmenuAula sma = new SubmenuAula();
                    sma.submenu(aula);
                    break;
                case 2:
                    SubmenuProducto smp = new SubmenuProducto();
                    smp.submenu(producto);
                    break;
                case 3:
                    SubmenuMarcajes smm = new SubmenuMarcajes();
                    smm.submenu(marcaje);
                    break;
                case 4:
                    SubmenuInforme smi = new SubmenuInforme();
                    smi.submenu(producto, aula);
                    break;
                case 5:
                    SubmenuDatos smd = new SubmenuDatos();
                    smd.submenu();
                    break;
                case 0:
                    System.out.println("Adios!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Introduzca una opcion valida.");
                    System.out.println();
                    break;
            }
            
        }while(opcionUser != 0);
        
        return opcionUser;
    }
    
}
