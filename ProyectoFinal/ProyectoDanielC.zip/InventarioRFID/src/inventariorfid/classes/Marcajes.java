/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Date;
import java.sql.Timestamp;

public class Marcajes {
    
    int idMarcaje;
    int idProducto;
    int idAula;
    String ipo;
    Timestamp timestamp;
    
    public Marcajes() {
        
        this.idMarcaje = 0;
        this.idProducto = 0;
        this.idAula = 0;
        this.ipo = "ENTRADA";
        this.timestamp = new Timestamp(new Date().getTime());
        
    }
    
    public Marcajes(int idMarcaje, Producto producto, Aula aula, String ipo, Timestamp timeStamp) {
        
        this.idMarcaje = idMarcaje;
        this.idProducto = producto.getID();
        this.idAula = aula.getID();
        this.ipo = ipo;
        this.timestamp = new Timestamp(new Date().getTime());
        
    }
    
    public Connection marcajesConnection() throws SQLException {
        Usuario u = new Usuario();
        Connection miCon = DriverManager.getConnection("jdbc:mysql://" + u.host, u.user, u.password);
    return miCon;
    }

    public int getIdMarcaje() {
        return idMarcaje;
    }

    public void setIdMarcaje(int idMarcaje) {
        this.idMarcaje = idMarcaje;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdAula() {
        return idAula;
    }

    public void setIdAula(int idAula) {
        this.idAula = idAula;
    }
    
    public String getIpo() {
        return this.ipo;
    }

    public void setIpo(String ipo) {
        this.ipo = ipo;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
}
