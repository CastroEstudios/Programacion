
package inventariorfid.classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Aula {
    
    int idAula;
    String numeracion;
    String descripcion;
    String ip;
    
    public Aula() {
        
        idAula = 0;
        numeracion = "";
        descripcion = "";
        ip = "";
    
    }
    
    public Aula(int idAula) {
        this.idAula = idAula;
    }
    
    public Aula(int idAula, String numeracion, String descripcion, String ip) {
        
        this.idAula = idAula;
        this.numeracion = numeracion;
        this.descripcion = descripcion;
        this.ip = ip;
        
    }
    
    public Connection aulaConnection() throws SQLException {
        Usuario u = new Usuario();
        Connection miCon = DriverManager.getConnection("jdbc:mysql://" + u.host, u.user, u.password);
    return miCon;
    }

    public int getID() {
        return idAula;
    }

    public void setID(int idAula) {
        this.idAula = idAula;
    }

    public String getNumeracion() {
        return numeracion;
    }

    public void setNumeracion(String numeracion) {
        this.numeracion = numeracion;
    }

    public String getDescription() {
        return descripcion;
    }

    public void setDescription(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
    
    @Override
    public String toString() {
        return idAula + "%" + numeracion + "%" + descripcion + "%" + ip;
    }
    
}