
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;
import inventariorfid.interfaces.SubmenuAulaDAO;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SubmenuAula implements SubmenuAulaDAO {
    
    String sentencia = "";
    boolean correcto = true;
    ArrayList<Aula> listaAulas = new ArrayList();
    ArrayList<Aula> listaAulasBorradas = new ArrayList();
    Aula miAula = new Aula();
    
    @Override
    public int submenu(){
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 1 - Aulas");
                System.out.println("1 - Insertar Aula");
                System.out.println("2 - Listar Aulas");
                System.out.println("3 - Eliminar Aula");
                System.out.println("4 - Modificar Aula");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1: {
                        insertar(listaAulas);
                        System.out.println();
                    }
                    case 2: {
                        listar();
                        System.out.println();
                    }
                    case 3: {
                        eliminar();
                        System.out.println();
                    }
                    case 4: {
                        modificar();
                        System.out.println();
                    }
                    case 0: {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default: {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();
            
        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        } catch (ParseException ex) {
            Logger.getLogger(SubmenuAula.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return opcionUser;
    }
    
    @Override
    public boolean insertar(ArrayList listaUsuarios) {
        try{
        Scanner s = new Scanner(System.in);
        System.out.print("Introduzca el ID del aula: ");
        int IDAula = s.nextInt();
        System.out.print("Introduzca la numeración del aula: ");
        String numeracionAula = s.nextLine();
        System.out.print("Introduzca la descripción del aula: ");
        String descripcionAula = s.nextLine();
        System.out.print("Introduzca la IP del aula: ");
        String ipAula = s.nextLine();
        Aula aula = new Aula(IDAula, numeracionAula, descripcionAula, ipAula);
        listaAulas.add(aula);
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean listar() {
        try {
        for(Aula aulaT:listaAulas) {
            System.out.println(aulaT);
        }
        System.out.println();
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean eliminar() {
        
        try {
        Scanner s = new Scanner(System.in);
        System.out.println("Introduzca la posición del aula que desea eliminar: ");
        int posAula = s.nextInt();
        Aula aulaT = listaAulas.remove(posAula);
        listaAulasBorradas.add(aulaT);
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
        
    }
    
    @Override
    public boolean modificar() {
        
        try {
            
        }
            
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        
        return correcto;
    }
    
}
