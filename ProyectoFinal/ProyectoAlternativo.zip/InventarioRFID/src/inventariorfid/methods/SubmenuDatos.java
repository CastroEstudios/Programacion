/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import inventariorfid.classes.Marcajes;
import inventariorfid.classes.Producto;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SubmenuDatos {
    
    boolean correcto = false;
    File file = new File(".\\Aula_fecha.dat");
    ArrayList<String> listaDatos = new ArrayList();
    
    public int submenu() {
        
        int opcionUser = 0;
        
        try {
            Scanner s = new Scanner(System.in);

            do {

                System.out.println("Sub Menu 5 - Datos");
                System.out.println("1 - Cargar datos de Prueba a fichero.");
                System.out.println("2 - Guardar datos de Prueba a fichero.");
                System.out.println("3 - Cargar datos de Base de Datos.");
                System.out.println("4 - Guardar datos de Base de Datos.");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1: {
                        cargarDatos();
                        System.out.println();
                    }
                    case 2: {
                        guardarDatos();
                        System.out.println();
                    }
                    case 3: {
                        System.out.println();
                    }
                    case 4: {
                        guardarBaseDatos();
                        System.out.println();
                    }
                    case 0: {
                        MenuPrincipal mp = new MenuPrincipal();
                        mp.MenuPrincipal();
                        System.out.println();
                        break;
                    }
                    default: {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                    }
                }

            }while(opcionUser != 0);

            s.close();

        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        return opcionUser;
        
    }
    
    public boolean cargarDatos() {
        try {
            Scanner s = new Scanner(file);
            while(s.hasNextLine()) {
                listaDatos.add(s.nextLine());
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(SubmenuDatos.class.getName()).log(Level.SEVERE, null, ex);
            correcto = false;
        }
        return correcto;
    }
    
    public boolean guardarDatos() throws IOException {
        return correcto;
    }
    
    public boolean clasificarDatos(ArrayList<Aula> listaAulas) {

    try {
        for(String sr:listaDatos) {
            String[] lineas = sr.split("%");
            String identificador = lineas[0].toUpperCase();

            switch (identificador) {
                case "AULA":
                    {
                        int lineasID = Integer.parseInt(lineas[1]);
                        Aula aula = new Aula(lineasID, lineas[2], lineas[3]
                                , lineas[4]);
                        listaAulas.add(aula);
                        break;
                    }
                case "PRODUCTO":
                    {
                        int lineasID = Integer.parseInt(lineas[1]);
                        Producto producto = new Producto(lineasID, lineas[2]
                                , lineas[3], lineas[4]);
                        listaProductos.add(producto);
                        break;
                    }
                case "MARCAJE":
                    {
                        int lineasID = Integer.parseInt(lineas[1]);
                        int lineasID2 = Integer.parseInt(lineas[2]);
                        int lineasID3 = Integer.parseInt(lineas[3]);
                        try{
                            SimpleDateFormat dateFormat =
                                    new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                            Date parsedDate = dateFormat.parse(lineas[5]);
                            Timestamp lineasTimestamp =
                                    new Timestamp(parsedDate.getTime());

                            Producto producto = new Producto(lineasID2);
                            Aula aula = new Aula(lineasID3);
                            Marcajes marcaje = new Marcajes(lineasID, producto, aula
                                    , lineas[4], lineasTimestamp);
                            listaMarcajes.add(marcaje);
                        }catch(Exception e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;
                    }
                default:
                    System.out.println("Datos incorrectos!");
                    break;
            }
        }
    } catch (Exception e) {
        System.out.println("Error: " + e.getMessage());
        correcto = false;
    }
    return correcto;
    }
        
    public boolean guardarBaseDatos(ArrayList<Aula> listaAulas) {
        clasificarDatos(listaAulas);
        try {
            SubmenuAula sma = new SubmenuAula();
            sma.insertar(listaAulas);
        }catch(Exception e){
            System.out.println("Error: " + e.getMessage());
        }
        
        return correcto;
    }
    
}
