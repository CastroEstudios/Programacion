/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package inventariorfid.interfaces;

import inventariorfid.classes.Aula;
import java.util.ArrayList;

public interface SubmenuAulaDAO {
    
    public int submenu();
    public boolean insertar(ArrayList listaAulas);
    public boolean listar();
    public boolean eliminar();
    public boolean modificar();
    
}
