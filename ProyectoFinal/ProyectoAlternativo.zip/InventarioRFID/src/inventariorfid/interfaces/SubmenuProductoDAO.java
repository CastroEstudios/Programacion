/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package inventariorfid.interfaces;

import inventariorfid.classes.Producto;
import java.sql.SQLException;

public interface SubmenuProductoDAO {
    
    public int submenu(Producto producto) throws SQLException;
    public boolean insertar(Producto producto) throws SQLException;
    public boolean listar(Producto producto) throws SQLException;
    public boolean eliminar(Producto producto) throws SQLException;
    public boolean modificar(Producto producto) throws SQLException;
    
}
