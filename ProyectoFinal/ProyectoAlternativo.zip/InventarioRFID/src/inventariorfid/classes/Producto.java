/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Producto {
    
    int idProducto;
    String descripcion;
    String EAN13;
    String keyRFID;
    
    public Producto() {
        
        idProducto = 0;
        descripcion = "";
        EAN13 = "0";
        keyRFID = "";
    
    }
    
    public Producto(int idProducto) {
        this.idProducto = idProducto;
    }
    
    public Producto(int idProducto, String descripcion, String EAN13
            , String keyRFID) {
        
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.EAN13 = EAN13;
        this.keyRFID = keyRFID;
        
    }
    
    public Connection productoConnection() throws SQLException {
        Usuario u = new Usuario();
        Connection miCon = DriverManager.getConnection("jdbc:mysql://" + u.host, u.user, u.password);
        return miCon;
    }

    public int getID() {
        return idProducto;
    }

    public void setID(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public String getEAN13() {
        return EAN13;
    }

    public void setEAN13(String EAN13) {
        this.EAN13 = EAN13;
    }

    public String getkeyRFID() {
        return keyRFID;
    }

    public void setkeyRFID(String keyRFID) {
        this.keyRFID = keyRFID;
    }
    
    @Override
    public String toString() {
        return idProducto + "%" + descripcion + "%" + EAN13 + "%" + keyRFID;
    }
    
}
