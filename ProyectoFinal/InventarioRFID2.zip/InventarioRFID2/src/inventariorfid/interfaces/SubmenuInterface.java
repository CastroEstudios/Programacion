
package inventariorfid.interfaces;

public interface SubmenuInterface {
    
    public int submenu();
    public boolean insertar();
    public boolean listar();
    public boolean eliminar();
    public boolean modificar();
    
}
