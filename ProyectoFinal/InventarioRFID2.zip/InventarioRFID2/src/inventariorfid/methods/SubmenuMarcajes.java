
package inventariorfid.methods;

import inventariorfid.classes.Marcajes;
import inventariorfid.classes.Marcajes.ipo;
import java.util.Scanner;
import inventariorfid.interfaces.SubmenuInterface;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SubmenuMarcajes implements SubmenuInterface {
    
    boolean correcto = true;
    ArrayList<Marcajes> listaMarcajes = new ArrayList();
    ArrayList<Marcajes> listaMarcajesBorrados = new ArrayList();
    ArrayList<Marcajes> listaMarcajesModificados = new ArrayList();
    
    @Override
    public int submenu(){
        
        int opcionUser = 0;
        
        Scanner s = new Scanner(System.in);
        do {
            correcto = true;
            System.out.println("Sub Menu 3 - Marcajes");
            System.out.println("1 - Insertar Marcaje");
            System.out.println("2 - Listar Marcajes");
            System.out.println("3 - Eliminar Marcaje");
            System.out.println("4 - Modificar Marcajes");
            System.out.println("0 - Volver");
            System.out.print("Introduzca opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    insertar();
                    System.out.println();
                    break;
                case 2:
                    listar();
                    System.out.println();
                    break;
                case 3:
                    eliminar();
                    System.out.println();
                    break;
                case 4:
                    modificar();
                    System.out.println();
                    break;
                case 0:
                    MenuPrincipal mp = new MenuPrincipal();
                    mp.MenuPrincipal();
                    System.out.println();
                    break;
                default:
                    System.out.println("Introduzca una opción válida.");
                    System.out.println();
                    break;
            }
            
        }while(opcionUser != 0);
        s.close();
        
        return opcionUser;
    }
    
    @Override
    public boolean insertar() {
        try{
            //Pedimos los datos
            Scanner s = new Scanner(System.in);
            System.out.println("Introduzca el ID del aula");
            int idMarcaje = s.nextInt();
            s.nextLine();
            System.out.print("Introduzca el ID del producto: ");
            int idProducto = s.nextInt();
            System.out.print("Introduzca el ID del aula: ");
            int idAula = s.nextInt();
            System.out.println("Introduzca el ipo del marcaje.");
            System.out.print("0 - Salida, 1 - Entrada: ");
            int ipoV = s.nextInt();
            ipo ipoS = null;
            switch (ipoV) {
                case 0:
                    ipoS = ipo.SALIDA;
                    break;
                case 1:
                    ipoS = ipo.ENTRADA;
                    break;
                default:
                    System.out.println("Valor incorrecto...");
                    correcto = false;
                    return correcto;
            }
            final String formatoFecha = "yyyy-MM-dd HH:mm:ss";
            System.out.println(formatoFecha);
            System.out.println("Utilice el formato especificado arriba a la hora"
                    + " de introducir la fecha.");
            System.out.println("(Puede simplemente presionar ENTER para"
                    + " introducir la fecha actual)");
            System.out.print("Introduzca la fecha: ");
            s.nextLine();
            String dateString = s.nextLine();
            Timestamp tsmp = new Timestamp(new Date().getTime());
            if(!dateString.isEmpty()) {
                SimpleDateFormat formatter = new SimpleDateFormat(formatoFecha);
                Date parsedDate = formatter.parse(dateString);
                tsmp = new java.sql.Timestamp(parsedDate.getTime());
            }
            Marcajes marcaje = new Marcajes(idMarcaje, idProducto, idAula
                    , ipoS, tsmp);
            //Lo añadimos al ArrayList y aumentamos
            //el contador del autonumérico.
            listaMarcajes.add(marcaje);
            System.out.println("Marcaje añadido correctamente.");
        }catch(ParseException e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean listar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaMarcajes.isEmpty()) {
                System.out.println("No hay marcajes almacenados que mostrar");
            }//Si no está vacío mostramos todo el contenido.
            else{
                for(Marcajes marcajeL:listaMarcajes) {
                    System.out.println(marcajeL);
                }
                System.out.println();
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean eliminar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaMarcajes.isEmpty()) {
                System.out.println("No hay marcajes almacenados que borrar.");
                correcto = false;
            }//Si no, pedimos el ID del aula a eliminar
            else{
                Scanner s = new Scanner(System.in);
                System.out.print("Introduzca el ID del marcaje que desea"
                        + " eliminar: ");
                int idMarcaje = s.nextInt();
                //Recorremos el ArrayList para encontrar el aula con el ID
                //introducido por el usuario.
                for(Marcajes marcajeD:listaMarcajes) {
                    //Si encuentra un aula con ese ID, la borra y la introduce
                    //en el ArrayList de AulasBorradas.
                    if(idMarcaje == marcajeD.getIdMarcaje()) {
                        listaMarcajesBorrados.add(marcajeD);
                        listaMarcajes.remove(marcajeD);
                        System.out.println("Se ha borrado correctamente");
                    }//Si no encuentra un aula con ese ID, lo informa.
                    else{
                        System.out.println("No hay ningún marcaje con"
                                + " ese ID.");
                        correcto = false;
                    }
                    if (listaMarcajes.isEmpty()) {
                        break;
                    }
                }
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto; 
    }
    
    @Override
    public boolean modificar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaMarcajes.isEmpty()) {
                System.out.println("No hay marcajes almacenados que modificar.");
                correcto = false;
            }//Si no, pedimos el ID del aula a modificar.
            else{
                Scanner s = new Scanner(System.in);
                System.out.print("Introduzca el ID del marcaje que desea"
                        + " modificar: ");
                int idMarcaje = s.nextInt();
                s.nextLine();
                //Recorremos el ArrayList para encontrar el aula con el ID
                //introducido por el usuario.
                for(Marcajes marcajeM:listaMarcajes) {
                    //Si encuentra un aula con ese ID, crea una nueva aula
                    //que sustituirá a la anterior.
                    if(idMarcaje == marcajeM.getIdMarcaje()) {
                        System.out.print("Introduzca el ID del marcaje: ");
                        idMarcaje = s.nextInt();
                        for(Marcajes marcajeL:listaMarcajes) { 
                            if(idMarcaje == marcajeL.getIdMarcaje()) {
                                System.out.println("ID duplicado!");
                                return correcto = false;
                            }
                        }
                        System.out.print("Introduzca el ID del producto: ");
                        int idProducto = s.nextInt();
                        System.out.print("Introduzca el ID del aula: ");
                        int idAula = s.nextInt();
                        System.out.println("Introduzca el ipo del marcaje.");
                        System.out.print("0 - Salida, 1 - Entrada: ");
                        int ipoV = s.nextInt();
                        ipo ipoS = null;
                        switch (ipoV) {
                            case 0:
                                ipoS = ipo.SALIDA;
                                break;
                            case 1:
                                ipoS = ipo.ENTRADA;
                                break;
                            default:
                                System.out.println("Valor incorrecto...");
                                correcto = false;
                                return correcto;
                        }
                        final String formatoFecha = "yyyy-MM-dd HH:mm:ss";
                        System.out.println(formatoFecha);
                        System.out.println("Utilice el formato especificado arriba a la hora"
                                + " de introducir la fecha.");
                        System.out.println("(Puede simplemente presionar ENTER para"
                                + " introducir la fecha actual)");
                        System.out.print("Introduzca la fecha: ");
                        s.nextLine();
                        String dateString = s.nextLine();
                        Timestamp tsmp = new Timestamp(new Date().getTime());
                        if(!dateString.isEmpty()) {
                            SimpleDateFormat formatter = new SimpleDateFormat(formatoFecha);
                            Date parsedDate = formatter.parse(dateString);
                            tsmp = new java.sql.Timestamp(parsedDate.getTime());
                        }
                        int posMarcaje = listaMarcajes.indexOf(marcajeM) + 1;
                        Marcajes marcajeN = new Marcajes(posMarcaje, idProducto, idAula
                                , ipoS, tsmp);
                        listaMarcajesModificados.add(marcajeM);
                        listaMarcajes.remove(marcajeM);
                        listaMarcajes.add(posMarcaje - 1, marcajeN);
                        System.out.println("Se ha modificado correctamente");
                        correcto = true;
                    }//Si no encuentra un aula con ese ID, lo informa.
                    else {
                        correcto = false;
                    }
                }
                //Si está duplicado informamos sobre ello
                if(correcto == false) {
                    System.out.println("No hay ningún marcaje con ese ID.");
                }
            }
        }catch(ParseException e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto; 
    }
}