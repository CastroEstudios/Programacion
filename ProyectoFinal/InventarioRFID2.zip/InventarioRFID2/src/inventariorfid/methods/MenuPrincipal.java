
package inventariorfid.methods;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

public class MenuPrincipal {
    SubmenuAula sma;
    public static void main(String[] args) throws SQLException, ParseException, FileNotFoundException {

        
        MenuPrincipal mp = new MenuPrincipal();
        mp.MenuPrincipal();
        
    }
    
    public int MenuPrincipal() {
        sma = new SubmenuAula();
        Scanner s = new Scanner(System.in);
        int opcionUser = 0;
        
        do {
            System.out.println("Menu Principal");
            System.out.println("1 - Gestion Aulas.");
            System.out.println("2 - Gestion Productos.");
            System.out.println("3 - Gestion Marcajes.");
            System.out.println("4 - Informes.");
            System.out.println("5 - Datos.");
            System.out.println("0 - Salir");
            System.out.print("Introduzca una opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    sma = new SubmenuAula();
                    sma.submenu();
                    break;
                case 2:
                    SubmenuProducto smp = new SubmenuProducto();
                    smp.submenu();
                    break;
                case 3:
                    SubmenuMarcajes smm = new SubmenuMarcajes();
                    smm.submenu();
                    break;
                case 4:
                    SubmenuInforme smi = new SubmenuInforme();
                    break;
                case 5:
                    SubmenuDatos smd = new SubmenuDatos();
                    smd.submenu();
                    
                    
                    
                    sma.setListaAulas(smd.getListaAulas());
                    break;
                case 0:
                    System.out.println("Adios!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Introduzca una opcion valida.");
                    System.out.println();
                    break;
            }
            
        }while(opcionUser != 0);
        
        return opcionUser;
    }
}

