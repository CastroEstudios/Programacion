
package inventariorfid.methods;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

public class MenuPrincipal {
    
    SubmenuAula sma;
    SubmenuProducto smp;
    SubmenuMarcajes smm;
    SubmenuInforme smi;
    SubmenuDatos smd;
    
    public MenuPrincipal() {
        sma = new SubmenuAula();
        smp = new SubmenuProducto();
        smm = new SubmenuMarcajes();
        smi = new SubmenuInforme();
        smd = new SubmenuDatos();
    }
    
    public static void main(String[] args) throws SQLException, ParseException, FileNotFoundException {

        MenuPrincipal mp = new MenuPrincipal();
        mp.MenuPrincipal();
        
    }
    
    public int MenuPrincipal() {

        int opcionUser = 0;
        
        do {
            Scanner s = new Scanner(System.in);
            opcionUser = 0;
            System.out.println("Menu Principal");
            System.out.println("1 - Gestion Aulas.");
            System.out.println("2 - Gestion Productos.");
            System.out.println("3 - Gestion Marcajes.");
            System.out.println("4 - Informes.");
            System.out.println("5 - Datos.");
            System.out.println("0 - Salir");
            System.out.print("Introduzca una opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    sma = new SubmenuAula();
                    sma.setListaAulas(smd.getListaAulas());
                    sma.submenu();
                    break;
                case 2:
                    smp = new SubmenuProducto();
                    smp.setListaProductos(smd.getListaProductos());
                    smp.submenu();
                    break;
                case 3:
                    smm = new SubmenuMarcajes();
                    smm.setListaMarcajes(smd.getListaMarcajes());
                    smm.submenu();
                    break;
                case 4:
                    smi = new SubmenuInforme();
                    break;
                case 5:
                    smd.submenu();
                    break;
                case 0:
                    System.out.println("Adios!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Introduzca una opcion valida.");
                    System.out.println();
                    break;
            }
            
        }while(opcionUser != 0);
        
        return opcionUser;
    }
}

