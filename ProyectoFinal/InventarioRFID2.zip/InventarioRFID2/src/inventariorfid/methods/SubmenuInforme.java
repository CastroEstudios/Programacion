
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import inventariorfid.classes.Producto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class SubmenuInforme {
    
    String sentencia = "";
    boolean correcto = false;
    Producto nuevoProducto = new Producto();
    Connection miCon;
    
    public int submenu() 
            throws SQLException, ParseException {
        
        int opcionUser = 0;
        
        Scanner s = new Scanner(System.in);
            System.out.println("Introduzca el host.");
            String host = s.nextLine();
            System.out.print("Introduzca el usuario: ");
            String user = s.nextLine();
            System.out.print("Introduzca la contraseña: ");
            String password = s.nextLine();
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" + host, user, password);
        do {    
            System.out.println("Sub Menu 4 - Informes");
            System.out.println("1 - Mostrar los fichajes de un producto"
                    + " ordenados por fecha");
            System.out.println("2 - Mostrar los fichajes de un aula entre"
                    + " dos fechas");
            System.out.println("3 - Mostrar los fichajes de un producto"
                    + "y un aula");
            System.out.println("4 - Informe a crear por el alumno");
            System.out.println("0 - Volver");
            System.out.print("Introduzca opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    mostrarFichajesProducto();
                    System.out.println();
                case 2:
                    mostrarFichajesAula();
                    System.out.println();
                case 3:
                    mostrarFichajesAulaProducto();
                    System.out.println();
                case 4:
                    System.out.println();
                case 0:
                    System.out.println();
                    break;
                default:
                        System.out.println("Introduzca una opción válida.");
                        System.out.println();
                }
            
        }while(opcionUser != 0);        
        return opcionUser;
    }
    
    public boolean mostrarFichajesProducto() {
        
        try {
            sentencia = (
                    "SELECT * "
                    + "FROM marcajes "
                    + "WHERE idProducto = ? "
                    + "ORDER BY Timestamp desc"
            );
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            System.out.print("Introduzca el ID del producto que desee consultar:");
            Scanner s = new Scanner(System.in);
            int idProducto = s.nextInt();
            s.nextLine();
            pstm.setInt(1, idProducto);
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) 
                            + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
    
    public boolean mostrarFichajesAula() throws ParseException {
        
        try {
            Scanner s = new Scanner(System.in);
            System.out.println("Introduzca la fecha inicial: ");
            String fechaInicialString = s.nextLine();
            System.out.println("Introduzca la fecha final: ");
            String fechaFinalString = s.nextLine();
        
            SimpleDateFormat f = new SimpleDateFormat("dd-MM-yyyy");

            Date dI = f.parse(fechaInicialString);
            long millisecondsI = dI.getTime();
            Timestamp fechaInicial = new Timestamp(millisecondsI);
            
            Date dF = f.parse(fechaFinalString);
            long millisecondsF = dF.getTime();
            Timestamp fechaFinal = new Timestamp(millisecondsF);
            
            System.out.println("Introduzca el host.");
            String host = s.nextLine();
            System.out.print("Introduzca el usuario: ");
            String user = s.nextLine();
            System.out.print("Introduzca la contraseña: ");
            String password = s.nextLine();
            Connection miCon = DriverManager.getConnection("jdbc:mysql://" + host, user, password);
            
            sentencia = (
                    "SELECT * "
                    + "FROM marcajes "
                    + "WHERE idAula = ? and Timestamp between ? and ? "
                    + "ORDER BY Timestamp desc"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            System.out.print("Introduzca el ID del aula que desee consultar:");
            int idAula = s.nextInt();
            s.nextLine();
            pstm.setInt(1, idAula);
            pstm.setTimestamp(2, fechaInicial);
            pstm.setTimestamp(3, fechaFinal);
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) 
                            + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
    
    public boolean mostrarFichajesAulaProducto() 
            throws ParseException {
        
        try {
            sentencia = (
                    "SELECT * "
                    + "FROM marcajes "
                    + "WHERE idAula = ? and idProducto = ? "
                    + "ORDER BY Timestamp desc"
            );
            
            PreparedStatement pstm = miCon.prepareStatement(sentencia);
            System.out.print("Introduzca el ID del aula que desee consultar:");
            Scanner s = new Scanner(System.in);
            int idAula = s.nextInt();
            System.out.print("Introduzca el ID del producto que desee consultar:");
            int idProducto = s.nextInt();
            pstm.setInt(1, idAula);
            pstm.setInt(2, idProducto);
            ResultSet rs = pstm.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int numColumnas = rsmd.getColumnCount();

            for(int i = 1; i <= numColumnas; i++) {
                System.out.print(rsmd.getColumnLabel(i) + " ");
            }
            
            System.out.println();

            while(rs.next()) {
                for (int j = 1; j <= numColumnas; j++) {
                    System.out.print(rs.getString(rsmd.getColumnLabel(j)) + "\t" + "\t");
                }
                System.out.println();
                correcto = true;
            }
            
            rs.close();

        }catch(SQLException e) {
            System.out.println();
            System.out.println("Error: " + e.getMessage());
            System.out.println();
        }
        
        return correcto;
    }
}
