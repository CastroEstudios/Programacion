
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import java.util.Scanner;
import inventariorfid.interfaces.SubmenuInterface;
import java.util.ArrayList;

public class SubmenuAula implements SubmenuInterface {
    
    boolean correcto = true;
    ArrayList<Aula> listaAulas = new ArrayList();
    ArrayList<Aula> listaAulasBorradas = new ArrayList();
    ArrayList<Aula> listaAulasModificadas = new ArrayList();
    
    @Override
    public int submenu(){
        
        int opcionUser = 0;
        
        Scanner s = new Scanner(System.in);
        do {
            correcto = true;
            System.out.println("Sub Menu 1 - Aulas");
            System.out.println("1 - Insertar Aula");
            System.out.println("2 - Listar Aulas");
            System.out.println("3 - Eliminar Aula");
            System.out.println("4 - Modificar Aula");
            System.out.println("0 - Volver");
            System.out.print("Introduzca opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    insertar();
                    System.out.println();
                    break;
                case 2:
                    listar();
                    System.out.println();
                    break;
                case 3:
                    eliminar();
                    System.out.println();
                    break;
                case 4:
                    modificar();
                    System.out.println();
                    break;
                case 0:
                    MenuPrincipal mp = new MenuPrincipal();
                    mp.MenuPrincipal();
                    System.out.println();
                    break;
                default:
                    System.out.println("Introduzca una opción válida.");
                    System.out.println();
                    break;
            }
            
        }while(opcionUser != 0);
        s.close();
        
        return opcionUser;
    }
    
    @Override
    public boolean insertar() {
        try{
            //Pedimos los datos para el aula
            Scanner s = new Scanner(System.in);
            System.out.println("Introduzca el ID del aula");
            int idAula = s.nextInt();
            s.nextLine();
            System.out.print("Introduzca la numeración del aula: ");
            String numeracionAula = s.nextLine();
            System.out.print("Introduzca la descripción del aula: ");
            String descripcionAula = s.nextLine();
            System.out.print("Introduzca la IP del aula: ");
            String ipAula = s.nextLine();
            Aula aula = new Aula(idAula, numeracionAula, descripcionAula, ipAula);
            //Lo añadimos al ArrayList y aumentamos
            //el contador del autonumérico.
            listaAulas.add(aula);
            System.out.println("Aula añadida correctamente.");
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean listar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaAulas.isEmpty()) {
                System.out.println("No hay aulas almacenadas que mostrar");
            }//Si no está vacío mostramos todo el contenido.
            else{
                for(Aula aulaL:listaAulas) {
                    System.out.println(aulaL);
                }
                System.out.println();
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean eliminar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaAulas.isEmpty()) {
                System.out.println("No hay aulas almacenadas que borrar.");
                correcto = false;
            }//Si no, pedimos el ID del aula a eliminar
            else{
                Scanner s = new Scanner(System.in);
                System.out.print("Introduzca el ID del aula que desea"
                        + " eliminar: ");
                int idAula = s.nextInt();
                //Recorremos el ArrayList para encontrar el aula con el ID
                //introducido por el usuario.
                for(Aula aulaD:listaAulas) {
                    //Si encuentra un aula con ese ID, la borra y la introduce
                    //en el ArrayList de AulasBorradas.
                    if(idAula == aulaD.getID()) {
                        listaAulasBorradas.add(aulaD);
                        listaAulas.remove(aulaD);
                        System.out.println("Se ha borrado correctamente");
                    }//Si no encuentra un aula con ese ID, lo informa.
                    else{
                        System.out.println("No hay ningún aula con"
                                + " ese ID.");
                        correcto = false;
                    }
                    if (listaAulas.isEmpty()) {
                        break;
                    }
                }   
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto; 
    }
    
    @Override
    public boolean modificar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaAulas.isEmpty()) {
                System.out.println("No hay aulas almacenadas que modificar.");
                correcto = false;
            }//Si no, pedimos el ID del aula a modificar.
            else{
                Scanner s = new Scanner(System.in);
                System.out.print("Introduzca el ID del aula que desea"
                        + " modificar: ");
                int idAula = s.nextInt();
                s.nextLine();
                //Recorremos el ArrayList para encontrar el aula con el ID
                //introducido por el usuario.
                for(Aula aulaM:listaAulas) {
                    //Si encuentra un aula con ese ID, crea una nueva aula
                    //que sustituirá a la anterior.
                    if(idAula == aulaM.getID()) {
                        //Pedimos los datos del nuevo aula.
                        System.out.print("Introduzca el ID del aula: ");
                        idAula = s.nextInt();
                        for(Aula aulaL:listaAulas) { 
                            if(idAula == aulaL.getID()) {
                                System.out.println("ID duplicado!");
                                return correcto = false;
                            }
                        }
                        System.out.print("Introduzca la numeración del aula: ");
                        String numeracionAula = s.nextLine();
                        System.out.print("Introduzca la descripción del aula: ");
                        String descripcionAula = s.nextLine();
                        System.out.print("Introduzca la IP del aula: ");
                        String ipAula = s.nextLine();
                        //Creamos el nuevo aula con los datos introducidos,
                        //borramos la anterior y añadimos la nueva en la misma
                        //posición.
                        int posAula = listaAulas.indexOf(aulaM) + 1;
                        Aula aulaN = new Aula(posAula, numeracionAula
                                , descripcionAula, ipAula);
                        listaAulasModificadas.add(aulaM);
                        listaAulas.remove(aulaM);
                        listaAulas.add(posAula, aulaN);
                        System.out.println("Se ha modificado correctamente");
                        correcto = true;
                    }//Si no encuentra un aula con ese ID, lo informa.
                    else {
                        correcto = false;
                    }
                }
                //Si está duplicado informamos sobre ello
                if(correcto == false) {
                    System.out.println("No hay ningún aula con ese ID.");
                }
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto; 
    }
    public ArrayList<Aula> getListaAulas() {
        return listaAulas;
    }

    public void setListaAulas(ArrayList<Aula> listaAulas) {
        this.listaAulas = listaAulas;
    }
    
}