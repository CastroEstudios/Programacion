
package inventariorfid.methods;

import inventariorfid.classes.Producto;
import java.util.Scanner;
import java.util.ArrayList;
import inventariorfid.interfaces.SubmenuInterface;

public class SubmenuProducto implements SubmenuInterface {
    
    boolean correcto = true;
    ArrayList<Producto> listaProductos = new ArrayList();
    ArrayList<Producto> listaProductosBorrados = new ArrayList();
    
    public SubmenuProducto() {
        listaProductos = new ArrayList();
        listaProductosBorrados = new ArrayList();
    }
    
    @Override
    public int submenu(){
        
        int opcionUser = 0;
        
        Scanner s = new Scanner(System.in);
        do {
            correcto = true;
            System.out.println("Sub Menu 2 - Productos");
            System.out.println("1 - Insertar Producto");
            System.out.println("2 - Listar Productos");
            System.out.println("3 - Eliminar Producto");
            System.out.println("4 - Modificar Producto");
            System.out.println("0 - Volver");
            System.out.print("Introduzca opcion: ");
            opcionUser = s.nextInt();
            System.out.println();
            
            switch(opcionUser) {
                case 1:
                    insertar();
                    System.out.println();
                    break;
                case 2:
                    listar();
                    System.out.println();
                    break;
                case 3:
                    eliminar();
                    System.out.println();
                    break;
                case 4:
                    modificar();
                    System.out.println();
                    break;
                case 0:
                    System.out.println();
                    break;
                default:
                    System.out.println("Introduzca una opción válida.");
                    System.out.println();
                    break;
            }
            
        }while(opcionUser != 0);        
        return opcionUser;
    }
    
    @Override
    public boolean insertar() {
        try{
            //Pedimos los datos para el aula menos el ID
            Scanner s = new Scanner(System.in);
            System.out.print("Introduzca el ID del producto: ");
            int idProducto = s.nextInt();
            s.nextLine();
            System.out.print("Introduzca la descripción del producto: ");
            String descripcionProducto = s.nextLine();
            System.out.print("Introduzca el EAN13 del producto: ");
            String ean13 = s.nextLine();
            System.out.print("Introduzca el keyRFID del producto: ");
            String keyRFID = s.nextLine();
            Producto producto = new Producto(idProducto, descripcionProducto
                    , ean13, keyRFID);
            for(Producto productoI:listaProductos) {
                if(productoI.getID() == producto.getID()) {
                    correcto = false;
                    break;
                }
            }
            //Lo añadimos al ArrayList y aumentamos
            //el contador del autonumérico.
            if(correcto == true) {
                listaProductos.add(producto);
                System.out.println("Producto añadido correctamente.");
            }else{
                System.out.println("Un producto con ese ID ya existe.");
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean listar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaProductos.isEmpty()) {
                System.out.println("No hay productos almacenadas que mostrar");
            }//Si no está vacío mostramos todo el contenido.
            else{
                for(Producto productoL:listaProductos) {
                    System.out.println(productoL);
                }
                System.out.println();
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    @Override
    public boolean eliminar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaProductos.isEmpty()) {
                System.out.println("No hay productos almacenados que borrar.");
                correcto = false;
            }//Si no, pedimos el ID del aula a eliminar
            else{
                Scanner s = new Scanner(System.in);
                System.out.print("Introduzca el ID del producto que desea"
                        + " eliminar: ");
                int idProducto = s.nextInt();
                //Recorremos el ArrayList para encontrar el aula con el ID
                //introducido por el usuario.
                for(Producto productoD:listaProductos) {
                    //Si encuentra un aula con ese ID, la borra y la introduce
                    //en el ArrayList de AulasBorradas.
                    if(idProducto == productoD.getID()) {
                        listaProductosBorrados.add(productoD);
                        listaProductos.remove(productoD);
                        System.out.println("Se ha borrado correctamente");
                    }//Si no encuentra un aula con ese ID, lo informa.
                    else{
                        System.out.println("No hay ningún producto con"
                                + " ese ID.");
                        correcto = false;
                    }
                    if (listaProductos.isEmpty()) {
                        break;
                    }
                }
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto; 
    }
    
    @Override
    public boolean modificar() {
        try {
            //Comprobamos si el ArrayList está vacío, si es así informamos
            //de ello.
            if(listaProductos.isEmpty()) {
                System.out.println("No hay productos almacenados que modificar.");
                correcto = false;
            }//Si no, pedimos el ID del aula a modificar.
            else{
                Scanner s = new Scanner(System.in);
                System.out.print("Introduzca el ID del producto que desea"
                        + " modificar: ");
                int idProducto = s.nextInt();
                s.nextLine();
                //Recorremos el ArrayList para encontrar el aula con el ID
                //introducido por el usuario.
                for(Producto productoM:listaProductos) {
                    //Si encuentra un aula con ese ID, crea una nueva aula
                    //que sustituirá a la anterior.
                    if(idProducto == productoM.getID()) {
                        //Pedimos los datos del nuevo aula.
                        System.out.print("Introduzca el ID del producto: ");
                        idProducto = s.nextInt();
                        for(Producto productoL:listaProductos) { 
                            if(idProducto == productoL.getID()) {
                                System.out.println("ID duplicado!");
                                correcto = false;
                            }
                        }
                        System.out.print("Introduzca la descripción del producto: ");
                        String descripcionProducto = s.nextLine();
                        System.out.print("Introduzca el EAN13 del producto: ");
                        String ean13 = s.nextLine();
                        System.out.print("Introduzca el keyRFID del producto: ");
                        String keyRFID = s.nextLine();
                        //Creamos el nuevo aula con los datos introducidos,
                        //borramos la anterior y añadimos la nueva en la misma
                        //posición.
                        int posProducto = listaProductos.indexOf(productoM) + 1;
                        Producto productoN = new Producto(posProducto, descripcionProducto, ean13, keyRFID);
                        listaProductosBorrados.add(productoM);
                        listaProductos.remove(productoM);
                        listaProductos.add(posProducto - 1, productoN);
                        System.out.println("Se ha modificado correctamente");
                        correcto = true;
                    }//Si no encuentra un aula con ese ID, lo informa.
                    else {
                        correcto = false;
                    }
                }
                //Si está duplicado informamos sobre ello
                if(correcto == false) {
                    System.out.println("No hay ningún producto con ese ID.");
                }
            }
        }catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto; 
    }
    
    public ArrayList<Producto> getListaProductos() {
        return listaProductos;
    }

    public void setListaProductos(ArrayList<Producto> listaProductos) {
        this.listaProductos = listaProductos;
    }
    
}