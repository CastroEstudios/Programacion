/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.methods;

import inventariorfid.classes.Aula;
import inventariorfid.classes.Marcajes;
import inventariorfid.classes.Marcajes.ipo;
import inventariorfid.classes.Producto;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SubmenuDatos {
    
    boolean correcto = true;
    ArrayList<String> listaCargarDatos = new ArrayList();
    SubmenuAula sma = new SubmenuAula();
    SubmenuProducto smp = new SubmenuProducto();
    SubmenuMarcajes smm = new SubmenuMarcajes();
    
    public SubmenuDatos( ) {
        this.sma = new SubmenuAula();
        this.smp = new SubmenuProducto();
        this.smm = new SubmenuMarcajes();
    }
    
    public int submenu() {
        
        int opcionUser = 0;
        
        try {
            do {
                Scanner s = new Scanner(System.in);
                System.out.println("Sub Menu 5 - Datos");
                System.out.println("1 - Cargar datos de Prueba a fichero.");
                System.out.println("2 - Guardar datos de Prueba a fichero.");
                System.out.println("3 - Cargar datos de Base de Datos.");
                System.out.println("4 - Guardar datos de Base de Datos.");
                System.out.println("0 - Volver");
                System.out.print("Introduzca opcion: ");
                opcionUser = s.nextInt();
                System.out.println();
                
                switch(opcionUser) {
                    case 1: {
                        cargarDatosFichero();
                        System.out.println();
                        break;
                    }
                    case 2: {
                        guardarDatosFichero();
                        System.out.println();
                        break;
                    }
                    case 3: {
                        System.out.println();
                        break;
                    }
                    case 4: {
                        System.out.println();
                        break;
                    }
                    case 0: {
                        System.out.println();
                        break;
                    }
                    default: {
                            System.out.println("Introduzca una opción válida.");
                            System.out.println();
                            break;
                    }
                }
            }while(opcionUser != 0);
        }catch(IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return opcionUser;
    }
    
    public boolean cargarDatosFichero() throws FileNotFoundException, IOException {
        Scanner s = new Scanner(System.in);
        System.out.println("0 - Cargar fichero de prueba.");
        System.out.println("1 - Cargar Aula_fecha.dat");
        System.out.print("Elija una opción: ");
        int opcionArchivo = s.nextInt();
        File file = null;
        switch(opcionArchivo) {
            case 0:
                file = new File(".\\Prueba.dat");
                break;
            case 1:
                file = new File(".\\Aula_fecha.dat");
                break;
        }   
        Scanner f = new Scanner(file);
        listaCargarDatos.clear();
        while(f.hasNext()) {
            listaCargarDatos.add(f.nextLine());
        }try {
            sma.listaAulas.clear();
            smp.listaProductos.clear();
            smm.listaMarcajes.clear();
            for(String sr:listaCargarDatos) {
                String[] lineas = sr.split("%");
                String identificador = lineas[0].toUpperCase();

                switch (identificador) {
                    case "AULA":
                        {
                            int lineasID = Integer.parseInt(lineas[1]);
                            Aula aula = new Aula(lineasID, lineas[2], lineas[3]
                                    , lineas[4]);
                            sma.listaAulas.add(aula);
                            break;
                        }
                    case "PRODUCTO":
                        {
                            int lineasID = Integer.parseInt(lineas[1]);
                            Producto producto = new Producto(lineasID, lineas[2]
                                    , lineas[3], lineas[4]);
                            smp.listaProductos.add(producto);
                            break;
                        }
                    case "MARCAJE":
                        {
                            int lineasID = Integer.parseInt(lineas[1]);
                            int lineasID2 = Integer.parseInt(lineas[2]);
                            int lineasID3 = Integer.parseInt(lineas[3]);
                            try{
                                Marcajes.ipo ipoS = null;
                                switch (lineas[4]) {
                                    case "ENTRADA":
                                        ipoS = Marcajes.ipo.ENTRADA;
                                        break;
                                    case "SALIDA":
                                        ipoS = Marcajes.ipo.SALIDA;
                                        break;
                                    default:
                                        ipoS = Marcajes.ipo.ENTRADA;
                                        break;
                                }
                                SimpleDateFormat dateFormat =
                                        new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                                Date parsedDate = dateFormat.parse(lineas[5]);
                                Timestamp lineasTimestamp =
                                        new Timestamp(parsedDate.getTime());
                                Marcajes marcaje = new Marcajes(lineasID, lineasID2
                                        , lineasID3, ipoS, lineasTimestamp);
                                smm.listaMarcajes.add(marcaje);
                            }catch(ParseException e) {
                                System.out.println("Error: " + e.getMessage());
                            }
                            break;
                        }
                    default:
                        System.out.println("Datos incorrectos detectados!");
                    break;
                }
            }
            System.out.println("Carga exitosa.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    public boolean guardarDatosFichero() {
        FileWriter fw = null;
        try {
            Scanner s = new Scanner(System.in);
            System.out.println("0 - Guardar a fichero de prueba.");
            System.out.println("1 - Guardar a Aula_fecha.dat");
            System.out.print("Elija una opción: ");
            int opcionArchivo = s.nextInt();
            File file = null;
            switch(opcionArchivo) {
                case 0:
                    file = new File(".\\Prueba.dat");
                    break;
                case 1:
                    file = new File(".\\Aula_fecha.dat");
                    break;
            }   
            fw = new FileWriter(file);
            while(!smm.listaMarcajes.isEmpty() && !smp.listaProductos.isEmpty()
                    && sma.listaAulas.isEmpty()) {
                for(Aula aulaG:sma.listaAulas) {
                    fw.write(aulaG.toString());
                    sma.listaAulas.remove(aulaG);
                }
                for(Producto productoG:smp.listaProductos) {
                    fw.write(productoG.toString());
                    smp.listaProductos.remove(productoG);
                }
                for(Marcajes marcajeG:smm.listaMarcajes) {
                    fw.write(marcajeG.toString());
                    smm.listaMarcajes.remove(marcajeG);
                }
            }
            System.out.println("Guardado exitoso.");
        } catch (IOException ex) {
            Logger.getLogger(SubmenuDatos.class.getName()).log(Level.SEVERE, null, ex);
            correcto = false;
        }
        return correcto;
    }
    
    public boolean cargarBaseDatos() throws SQLException, ParseException {
        try {
        Scanner s = new Scanner(System.in);
        System.out.println("Introduzca el host.");
        String host = s.nextLine();
        System.out.print("Introduzca el usuario: ");
        String user = s.nextLine();
        System.out.print("Introduzca la contraseña: ");
        String password = s.nextLine();
        Connection miCon = DriverManager.getConnection("jdbc:mysql://" + host, user, password);
        String sentencia = "SELECT * FROM aulas";
        PreparedStatement pstm = miCon.prepareStatement(sentencia);
        ResultSet rs = pstm.executeQuery();
        while(rs.next()) {
            int idAula = rs.getInt("idAula");
            String numeracion = rs.getString("numeracion");
            String descripcion = rs.getString("descripcion");
            String ip = rs.getString("ip");
            Aula aulaT = new Aula(idAula, numeracion, descripcion, ip);
            sma.listaAulas.add(aulaT);
        }
        sentencia = "SELECT * FROM productos";
        pstm = miCon.prepareStatement(sentencia);
        rs = pstm.executeQuery();
        while(rs.next()) {
            int idProducto = rs.getInt("idProducto");
            String descripcion = rs.getString("descripcion");
            String ean13 = rs.getString("ean13");
            String keyRFID = rs.getString("keyRFID");
            Producto productoT = new Producto(idProducto, descripcion, ean13, keyRFID);
            smp.listaProductos.add(productoT);
        }
        sentencia = "SELECT * FROM marcajes";
        pstm = miCon.prepareStatement(sentencia);
        rs = pstm.executeQuery();
        while(rs.next()) {
            int idMarcaje = rs.getInt("idMarcaje");
            int idProducto = rs.getInt("idProducto");
            int idAula = rs.getInt("idAula");
            String ipoStr = rs.getString("ipo");
            ipo ipoS = null;
            switch (ipoStr) {
                case "SALIDA":
                    ipoS = Marcajes.ipo.SALIDA;
                    break;
                case "ENTRADA":
                    ipoS = Marcajes.ipo.ENTRADA;
                    break;
            }
            final String formatoFecha = "yyyy-MM-dd HH:mm:ss";
            String dateString = rs.getString("Timestamp");
            SimpleDateFormat formatter = new SimpleDateFormat(formatoFecha);
            Date parsedDate = formatter.parse(dateString);
            Timestamp tsmp = new java.sql.Timestamp(parsedDate.getTime());
            Marcajes marcajeT = new Marcajes(idMarcaje, idProducto, idAula
                    , ipoS, tsmp);
            smm.listaMarcajes.add(marcajeT);
        }
        }catch(SQLException | ParseException e){
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    public boolean guardarBaseDatos() {
        try {
        Scanner s = new Scanner(System.in);
        System.out.println("Introduzca el host.");
        String host = s.nextLine();
        System.out.print("Introduzca el usuario: ");
        String user = s.nextLine();
        System.out.print("Introduzca la contraseña: ");
        String password = s.nextLine();
        Connection miCon = DriverManager.getConnection("jdbc:mysql://" + host, user, password);
        String sentencia = "INSERT INTO aulas (numeracion, descripcion, ip)"
                + " VALUES(?,?,?)";
        PreparedStatement pstm = miCon.prepareStatement(sentencia);
        for(Aula aulaT:sma.listaAulas) {
            pstm.setString(0, aulaT.getNumeracion());
            pstm.setString(1, aulaT.getDescription());
            pstm.setString(2, aulaT.getIp());
        }
        pstm.executeUpdate();
        sentencia = "INSERT INTO productos(descripcion, ean13, keyRFID)"
                + " VALUES(?,?,?,?)";
        pstm = miCon.prepareStatement(sentencia);
        for(Producto productoT:smp.listaProductos) {
            pstm.setString(0, productoT.getDescripcion());
            pstm.setString(1, productoT.getEAN13());
            pstm.setString(2, productoT.getkeyRFID());
        }
        pstm.executeUpdate();
        sentencia = "INSERT INTO marcajes(idProducto, idAula, ipo, Timestamp)"
                + " VALUES(?,?,?,?)";
        pstm = miCon.prepareStatement(sentencia);
        for(Marcajes marcajeT:smm.listaMarcajes) {
            pstm.setInt(0, marcajeT.getIdProducto());
            pstm.setInt(1, marcajeT.getIdAula());
            ipo ipoS = marcajeT.getIpo();
            String ipo = ipoS.toString();
            pstm.setString(2, ipo);
            pstm.setTimestamp(3, marcajeT.getTimestamp());
        }
        pstm.executeUpdate();
        sentencia = "DELETE FROM aulas where idAula = ?";
        pstm = miCon.prepareStatement(sentencia);
        for(Aula aulaT:sma.listaAulasBorradas) {
            pstm.setInt(0, aulaT.getID());
        }
        pstm.executeUpdate();
        sentencia = "DELETE FROM productos where idProducto = ?";
        pstm = miCon.prepareStatement(sentencia);
        for(Producto productoT:smp.listaProductosBorrados) {
            pstm.setInt(0, productoT.getID());
        }
        pstm.executeUpdate();
        sentencia = "DELETE FROM marcajes where idMarcajes = ?";
        pstm = miCon.prepareStatement(sentencia);
        for(Marcajes marcajeT:smm.listaMarcajesBorrados) {
            pstm.setInt(0, marcajeT.getIdMarcaje());
        }
        pstm.executeUpdate();
        }catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
            correcto = false;
        }
        return correcto;
    }
    
    public ArrayList<Aula> getListaAulas() {
        return sma.listaAulas;
    }
    public ArrayList<Producto> getListaProductos() {
        return smp.listaProductos;
    }
    public ArrayList<Marcajes> getListaMarcajes() {
        return smm.listaMarcajes;
    }
    
}
