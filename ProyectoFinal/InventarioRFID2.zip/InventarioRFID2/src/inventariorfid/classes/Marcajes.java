/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventariorfid.classes;

import java.util.Date;
import java.sql.Timestamp;

public class Marcajes {
    
    int idMarcaje;
    int idProducto;
    int idAula;
    public enum ipo {
        ENTRADA, SALIDA
    }
    ipo ipoS = null;
    Timestamp timestamp;
    
    public Marcajes() {
        
        this.idMarcaje = 0;
        this.idProducto = 0;
        this.idAula = 0;
        ipo ipoS = ipo.SALIDA;
        this.timestamp = new Timestamp(new Date().getTime());
        
    }
    
    public Marcajes(int idMarcaje, int idProducto, int idAula, ipo ipoS, Timestamp timeStamp) {
        
        this.idMarcaje = idMarcaje;
        this.idProducto = idProducto;
        this.idAula = idAula;
        this.ipoS = ipoS;
        this.timestamp = new Timestamp(new Date().getTime());
        
    }

    public int getIdMarcaje() {
        return idMarcaje;
    }

    public void setIdMarcaje(int idMarcaje) {
        this.idMarcaje = idMarcaje;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public int getIdAula() {
        return idAula;
    }

    public void setIdAula(int idAula) {
        this.idAula = idAula;
    }
    
    public ipo getIpo() {
        return this.ipoS;
    }

    public void setIpo(ipo ipoS) {
        this.ipoS = ipoS;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    @Override
    public String toString() {
        return "Marcaje" + "%" + idMarcaje + "%" + idProducto + "%" + idAula + "%" + ipoS + "%" + timestamp;
    }
    
}
