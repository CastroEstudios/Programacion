
package inventariorfid.classes;

public class Aula implements Comparable<Aula>{
    
    int idAula;
    String numeracion;
    String descripcion;
    String ip;
    
    public Aula() {
        
        idAula = 0;
        numeracion = "";
        descripcion = "";
        ip = "";
    
    }
    
    public Aula(int idAula, String numeracion, String descripcion, String ip) {
        
        this.idAula = idAula;
        this.numeracion = numeracion;
        this.descripcion = descripcion;
        this.ip = ip;
        
    }

    public int getID() {
        return idAula;
    }

    public void setID(int idAula) {
        this.idAula = idAula;
    }

    public String getNumeracion() {
        return numeracion;
    }

    public void setNumeracion(String numeracion) {
        this.numeracion = numeracion;
    }

    public String getDescription() {
        return descripcion;
    }

    public void setDescription(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }
    
    @Override
    public String toString() {
        return "Aula" + "%" + idAula + "%" + numeracion + "%" + descripcion + "%" + ip;
    }
    
    @Override
    public int compareTo(Aula aulaT) {
        int valor = 0;
        if(this.getID() < aulaT.getID()) {
            valor = -1;
        }
        if(this.getID() > aulaT.getID()) {
            valor = 1;
        }
        return valor;
    }
}