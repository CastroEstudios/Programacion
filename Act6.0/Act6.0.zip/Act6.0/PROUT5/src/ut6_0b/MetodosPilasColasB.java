package ut6_0b;

import java.io.File;
import java.util.ArrayList;

public class MetodosPilasColasB implements InterfazPilaB, InterfazColaB {

	@Override
	public ArrayList<File> crearPila() {
		ArrayList<File> pila = new ArrayList<File>();
		return pila;
	}

	@Override
	public void apilarPila(File insercion, ArrayList<File> pila) {
		pila.add(0,insercion);
	}

	@Override
	public void desapilar(ArrayList<File> pila) {
		pila.remove(0);
	}

	@Override
	public File cima(ArrayList<File> pila) {
		return pila.get(0);
	}

	@Override
	public boolean vacia(ArrayList<File> pila) {
		return pila.isEmpty();	
	}

	@Override
	public ArrayList<File> crearCola() {
		ArrayList<File> cola = new ArrayList<File>();
		return cola;
	}

	@Override
	public void encolar(File insercion, ArrayList<File> cola) {
		cola.add(insercion);
	}

	@Override
	public void desencolar(ArrayList<File> cola) {
		cola.remove(0);
		
	}

	@Override
	public File frente(ArrayList<File> cola) {
		return cola.get(0);
	}

	@Override
	public boolean vaciaCola(ArrayList<File> cola) {
		return cola.isEmpty();
		
	}
}
