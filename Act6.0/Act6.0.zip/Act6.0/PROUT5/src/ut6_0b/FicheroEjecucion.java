package ut6_0b;

import java.io.File;
import java.util.ArrayList;

public class FicheroEjecucion {

	public static void main(String[] args) {
		
		File fichero = new File("./MiDir");
		MetodosPilasColasB pilasColas2 = new MetodosPilasColasB();
		ArrayList<File> pila = pilasColas2.crearPila();
		FicheroEjecucion prueba = new FicheroEjecucion();
		prueba.pilaFichero(fichero, pila);
		System.out.println("Terminado");
		System.out.println();
		prueba.colaFichero(fichero, pila);
		System.out.println("Terminado");
	}

	
	
	public void pilaFichero(File fichero, ArrayList<File> pila) {
		
		MetodosPilasColasB pilasColas2 = new MetodosPilasColasB();
		File[] ficherosArray = fichero.listFiles();
		
			for (File file : ficherosArray) {
				if(file.isDirectory()) {
					pilasColas2.apilarPila(file, pila);
				}
				else {
					continue;
				}
			}
			System.out.print("| ");
			for (File elemento : pila) {
				System.out.print(elemento.getName() + " | ");
			}
			System.out.println();
			fichero = pilasColas2.cima(pila);
			pilasColas2.desapilar(pila);
			if(!pilasColas2.vacia(pila)) {
			pilaFichero(fichero, pila);
			}
	}
	
	
	public void colaFichero(File fichero, ArrayList<File> cola) {
		
		MetodosPilasColasB pilasColas2 = new MetodosPilasColasB();
		File[] ficherosArray = fichero.listFiles();
		
			for (File file : ficherosArray) {
				if(file.isDirectory()) {
					pilasColas2.encolar(file, cola);
				}
				else {
					continue;
				}
			}
			System.out.print("| ");
			for (File elemento : cola) {
				System.out.print(elemento.getName() + " | ");
			}
			System.out.println();
			fichero = pilasColas2.frente(cola);
			pilasColas2.desencolar(cola);
			if(!pilasColas2.vacia(cola)) {
			colaFichero(fichero, cola);
			}
	}
	
	
}
