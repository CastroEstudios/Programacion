package ut6_0b;

import java.io.File;
import java.util.ArrayList;

public interface InterfazPilaB {

	ArrayList<File> crearPila();
	void apilarPila(File insercion, ArrayList<File> pila);
	void desapilar(ArrayList<File> pila);
	Object cima(ArrayList<File> pila);
	boolean vacia(ArrayList<File> pila);
	
}
