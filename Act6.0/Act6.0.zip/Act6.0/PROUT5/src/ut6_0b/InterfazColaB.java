package ut6_0b;

import java.io.File;
import java.util.ArrayList;

public interface InterfazColaB {

	ArrayList<File> crearCola();
	void encolar(File insercion, ArrayList<File> cola);
	void desencolar(ArrayList<File> cola);
	File frente(ArrayList<File> cola);
	boolean vaciaCola(ArrayList<File> cola);
	
}
