package clasetiempo4_3;

/**
 *
 * @author Daniel Castro Cruz
 */
public class ClaseTiempo {

	private int dia;
	private int hora;
	private int minutos;
	private int segundos;
	private int[] guardarSuma = new int[3];
	private String horaCompleta = "";

	public ClaseTiempo(int dia, int hora, int minutos, int segundos, int[] guardarSuma) {

		this.dia = dia;
		this.hora = hora;
		this.minutos = minutos;
		this.segundos = segundos;
		this.guardarSuma = guardarSuma;

	}

	public String TiempoReloj() {

		// C�digo que suma los valores almacenados en el array
		// guardarSuma y los suma a la hora, minutos y segundos
		// dados por el usuario.
		
		int sumaSegundos = guardarSuma[3] + this.segundos;
		int sumaMinutos = guardarSuma[2] + this.minutos;
		int sumaHora = guardarSuma[1] + this.hora;
		int sumaDia = guardarSuma[0] + this.dia;
		
		while(sumaSegundos >= 60) {
			sumaSegundos -= 60;
			sumaMinutos++;
		}
		this.segundos = guardarSuma[3];
		
		while(sumaMinutos >= 60) {
			sumaMinutos -= 60;
			sumaHora++;
		}
		
		while(sumaHora >= 24) {
			sumaHora -= 24;
			sumaDia++;
		}
		
		
		horaCompleta = "Son las " + sumaHora + ":" + sumaMinutos + ":" 
		+ sumaSegundos + " del d�a " + sumaDia;
		
		System.out.println(horaCompleta);
			
		return horaCompleta;
	}
	
	
	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		this.dia = dia;
	}

	public int getHora() {
		return hora;
	}

	public void setHora(int hora) {
		this.hora = hora;
	}

	public int getMinutos() {
		return minutos;
	}

	public void setMinutos(int minutos) {
		this.minutos = minutos;
	}

	public int getSegundos() {
		return segundos;
	}

	public void setSegundos(int segundos) {
		this.segundos = segundos;
	}

	public String getHoraTotal() {
		return horaCompleta;
	}

}
