package clasetiempo4_3;
/**
 *
 * @author Daniel Castro Cruz
 */
public class ClaseTiempoLlamada {
    public static void main(String[] args) {
    	
    	/* Array que almacena la suma a afectuar a la hora 
    	 * dada en "new ClaseTiempo" 
    	 * {dias, horas, minutos, segundos}*/
        int guardarSuma[] = {8,15,80,80};
        
        /* Hora a la que se sumar� el array guardarSuma*/
        ClaseTiempo prueba = new ClaseTiempo(22,15,19,20,guardarSuma);
        
        prueba.TiempoReloj();
    }
}