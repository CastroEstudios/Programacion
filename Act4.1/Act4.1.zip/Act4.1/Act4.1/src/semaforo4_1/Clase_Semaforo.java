package semaforo4_1;

public class Clase_Semaforo {
		
	public enum Colores {
			VERDE, AMARILLO, ROJO;
		}
	
	public Colores estadoColor;
	
	public Clase_Semaforo() {

	}
	
	public static void ronda() throws InterruptedException {
		System.out.print (Colores.VERDE);
		Thread.sleep(6000);
		System.out.print("\b\b\b\b\b");
		System.out.print (Colores.AMARILLO);
		Thread.sleep(2000);
		System.out.print("\b\b\b\b\b\b\b\b");
		System.out.print (Colores.ROJO);
		Thread.sleep(4000);
		System.out.print("\b\b\b\b");
		
	}
	
	 public Colores getVerde() {
         return Colores.VERDE;
     }
	 
	 public Colores getAmarillo() {
         return Colores.AMARILLO;
     }
	 
	 public Colores getRojo() {
         return Colores.ROJO;
     }
}
	
