package semaforo4_1;

public class Semaforo_Llamada {

	public static void main(String[] args) throws InterruptedException {
		Clase_Semaforo.ronda();
	}

}
