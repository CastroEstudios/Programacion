/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package act3_5;

import java.util.Scanner;

/**
 *
 * @author Daniel
 */
public class UT3_5 {
    public static void main(String[] args){
        char ultimaLetra;
        String fraseMayus = "";
        Scanner teclado = new Scanner(System.in);
        System.out.print("Escriba una frase: ");
        String fraseUsuario = teclado.nextLine();
        char primeraLetra = Character.toUpperCase(fraseUsuario.charAt(0));
        ultimaLetra = primeraLetra;
        fraseMayus += ultimaLetra;
        for (int contadorString = 1 ; contadorString < fraseUsuario.length() ; contadorString++) {
            char letraCheck = fraseUsuario.charAt(contadorString);
            if (Character.isSpaceChar(ultimaLetra)){
                letraCheck = Character.toUpperCase(letraCheck);
            }
            ultimaLetra = letraCheck;
            fraseMayus += ultimaLetra;
        }
        System.out.println(fraseMayus);
    }
}
